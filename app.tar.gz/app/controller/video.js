const {httpCode} = require('../util/httpCode');
const archiver = require('archiver');  //文件下载模块
const send = require('koa-send'); //文件发送
const fs = require('fs');
const path = require('path');

module.exports = app => {
  class VideoController extends app.Controller {
    //上传json文件
    async sourceData() {
      const {ctx, service} = this;
      let str = decodeURIComponent(ctx.request.body.sourceData);
      let data = JSON.parse(str);
      let projectName = data.projectName;
      let result = await service.image.saveSource(data, projectName);
      ctx.status = 200;
      ctx.body = httpCode('success', {data: result});
    }
    //下载功能
    async download() {
      const {ctx, service} = this;
      const projectName = ctx.params.projectName;
      let publicDir = `public/${projectName}/`;
      let uploadDir = path.resolve(pcwApp.rootDir, publicDir);
      let zipName = `${projectName}.zip`;
      const zipStream = fs.createWriteStream(zipName);
      const zip = archiver('zip');
      zip.pipe(zipStream);
      // 添加整个文件夹到压缩包
      zip.directory(uploadDir, projectName);
      await zip.finalize();
      ctx.attachment(zipName);
      await send(ctx, zipName);
    }
    //上传zip文件
    async uploadZip() {
      console.log('==========upload');
      let {ctx,service} = this;
      let method = ctx.request.method;
      let data;
      if(method == 'OPTIONS') {
        data = {data:'success'}; 
      }else if(method == 'POST') {
        data = await service.image.uploadZip(); //返回json数据
      }
      ctx.status = 200;
      
      ctx.body = httpCode('success', data);
    }
  }
  return VideoController;
}