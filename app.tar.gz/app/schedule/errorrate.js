'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: 中间层定时任务
 * @author: sunshitao@qiyi.com
 * @date:   2018-07-13
 */
let count = 1;
 module.exports = {
  schedule: {
    interval: '9s',
    type: 'all',  //指定所有work都需要执行
  },
  async task(ctx) {
    console.log('======='+(count++));
  }  
}