'use strict';
const {commonMiddleWares} = require('./middleWare/middleWares');
const staticUtil = require('./util/static');
const path = require('path');

module.exports = app => {
    const {router,controller} = app;
    router.get('/pcwapi', controller.index.welcome);
    router.post('/video/sourcedata', commonMiddleWares, controller.video.sourceData);
    router.options('/image/upload', commonMiddleWares, controller.image.upload);
    router.post('/image/upload', commonMiddleWares, controller.image.upload);
    router.options('/video/uploadzip', commonMiddleWares, controller.video.uploadZip);
    router.post('/video/uploadzip', commonMiddleWares, controller.video.uploadZip);
    router.get('/video/download/:projectName', commonMiddleWares, controller.video.download);
    router.get('*',async (ctx) => {
        const requestOrigin = ctx.accept.headers.origin;
        ctx.set({
            'Access-Control-Allow-Origin': requestOrigin,
            'Access-Control-Allow-Credentials': true,
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Methods': 'PUT,POST,GET',
        });
        // 静态资源目录在本地的绝对路径
        let fullStaticPath = path.join(__dirname, '../')
        let _mime = staticUtil.parseMime(ctx.url)
        // 获取静态资源内容，有可能是文件内容，目录，或404
        let _content = await staticUtil.content(ctx, fullStaticPath,_mime)

        // 解析请求内容的类型

        // 如果有对应的文件类型，就配置上下文的类型
        if (_mime) {
            ctx.type = _mime
        }

        // 输出静态资源内容
        if (_mime && _mime.indexOf('image/') >= 0) {
            // 如果是图片，则用node原生res，输出二进制数据
            ctx.res.writeHead(200)
            ctx.res.write(_content, 'binary')
            ctx.res.end()
        } else {
            // 其他则输出文本
            // ctx.type = 'text/plain; charset=utf-8';
            ctx.body = _content
        }
    });
    
};
