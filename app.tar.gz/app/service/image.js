const formidable = require('koa-formidable'); // 图片处理
const fs = require('fs');
const path = require('path');
const {ProcessApi} = require('../util/innerprocess');

let mkdirs = (dirname, callback)=> {
  fs.exists(dirname, function(exists) {
      if (exists) {
          callback();
      } else {
          mkdirs(path.dirname(dirname), function() {
              fs.mkdir(dirname, callback);
          });
      }
  });
};
module.exports = app => {
  class ImageService extends app.Service {
    constructor(ctx) {
      super(ctx);
    }
    async upload() {
      const {ctx} = this;
      let form = formidable.parse(ctx.request);
      function formImage() {
        return new Promise((resolve, reject) => {
          form((opt, {fields, files})=> {
            let filename = files.file.name;
            let projectName = fields.projectName; //前端加上时间戳防止名字重复
            console.log(files.file.path);
            let publicDir = `public/${projectName}/`;

            let uploadDir = path.resolve(pcwApp.rootDir, publicDir);
            let avatarName = filename;
            mkdirs(uploadDir, function() {
              fs.renameSync(files.file.path, uploadDir +'/'+ avatarName); //重命名
              
              resolve({url: projectName+ '/' + avatarName, imgIndex:fields.imgIndex})
              // http://localhost:6001/public/upload/1513523744257_WX20171205-150757.png
            })
          })
        })
      }
      let data = await formImage();
      return data;
    }
    //保存数据
    async saveSource(sourceData, projectName) {
      let publicDir = `public/${projectName}/`;
      let uploadDir = path.resolve(pcwApp.rootDir, publicDir);
      let sourceName = 'index.json';
      function writeData(sourceData1, sourceName1) {
        return new Promise((resolve, reject) => {
          mkdirs(uploadDir, function() {
            fs.writeFileSync(uploadDir+'/'+sourceName1, sourceData1, 'utf-8');
            resolve('success');
          });
        });
      }
      let result = await writeData(JSON.stringify(sourceData), sourceName);
      return result;
    }
    async uploadZip() {
      const {ctx} = this;
      let form = formidable.parse(ctx.request);
      function formImage() {
        return new Promise((resolve, reject) => {
          form((opt, {fields, files})=> {
            let filename = files.file.name;
            let projectName = path.basename(filename, '.zip');
            console.log(files.file.path);
            let publicDir = `public/`;
            let uploadDir = path.resolve(pcwApp.rootDir, publicDir);
            mkdirs(uploadDir, async function() {
              fs.renameSync(files.file.path, uploadDir+'/'+filename); //重命名
              let result = await ProcessApi.execUnzipCmd(uploadDir+'/'+filename, uploadDir);
              console.log(JSON.stringify(result)+'~~~~~~~~~');

              let jsonfile = uploadDir+'/'+projectName+'/index.json';
              let jsonData = fs.readFileSync(jsonfile, 'utf-8');
              fs.unlinkSync(jsonfile); //读取完数据后删除json文件
              //解压压缩包
              resolve(JSON.parse(jsonData));
              // http://localhost:6001/public/upload/1513523744257_WX20171205-150757.png
            })
          })
        })
      }
      let data = await formImage();
      return data;
    }
  }
  return ImageService;
}