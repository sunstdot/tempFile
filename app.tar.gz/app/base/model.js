/**
 * Copyright (C) 2018 iQIYI (www.iqiyi.com).
 * All Rights Reserved.
 * @desc: Model data structure for data processing
 * @function:
 * - basic Model for data Model inheritance
 * - define data properties and formatter
 * - watching data change from Proxy
 * @author: lichunping@qiyi.com
 * @date: 2018-04-01
 */
'use strict';
const {
  addUpdateListener,
  observeObject,
  format,
  defineProperty
} = require('../util/model')
// constant
if (typeof ROOT === undefined) {
  const ROOT = this
}

const _PROXY_ = Symbol('proxy')
const _FORMATTER_ = Symbol('formatter')
const __TYPE__ = Symbol('type')

module.exports = app => {
  /** Class base Model */
  class Model extends app.Model {
    constructor(type) {
      super();
      // watcher from Proxy
      defineProperty(this, _PROXY_, observeObject(this), false)
      defineProperty(this, _FORMATTER_, {}, false)
      defineProperty(this, __TYPE__, type, false)
    }

    /**
     * define properties for Model
     * @param {Object} props - properties key and value.
     * @param {JSON} [source] - The source JSON object.
     * @example define({name:'Tom', gender: 1},
     *                 {gender: (key, value) => value === 1 ? 'boy': 'gril'})
     */
    define(props, source) {
      for (let key in props) {
        if (source && source[key] !== undefined) {
          this[key] = source[key]
        } else {
          this[key] = props[key]
        }
      }
    }

    /**
     * initial formatter and to execute
     * @param {JSON} source - The source JSON object.
     * @param {Object} [formatter] - properties key and value.
     * @example init({name:'Tom'}, {name: 'Jack'})
     */
    init(source, formatter) {
      this.getPrototype().setFormatter.call(this, formatter, false)
      let result = this.preprocess(source, formatter)
      defineProperty(this, '__source__', source, false, {
        writable: false
      })
      if (result !== false) {
        this.getPrototype().format.call(this)
      }
      return this
    }

    getPrototype() {
      return Object.getPrototypeOf(this);
    }

    get [Symbol.toStringTag]() {
      return 'Model'
    }

    getProxy() {
      return this[_PROXY_]
    }

    getSource() {
      return this['__source__']
    }

    getFormatter() {
      return this[_FORMATTER_]
    }
    getType() {
      return this[__TYPE__]
    }

    addFormatter(formatter) {
      return this.getPrototype().setFormatter.call(this, formatter, false)
    }

    setFormatter(formatter, override = true) {
      if (override) {
        this[_FORMATTER_] = formatter
      } else {
        Object.assign(this.getPrototype().getFormatter.call(this), formatter)
      }
      return this
    }

    /**
     * for override to preprocess source data.
     * if return false will not execute format.
     */
    preprocess() {
      return true
    }

    /**
     * process data by formatter
     * @param {Object.<string, (value|Function|Array)} [formatter] - format property by config
     * @param {boolean} [whole] - whether this one formatter parameter only
     * @example
     * formart({
     *   key: value | function(key, value, source, model, formatter) {
     *       return value | array(['firstKey', 'secondKey', 'nextKey'])
     *   }
     * })
     * @return {Model} this
     */
    format(formatter, whole = true) {
      if (formatter && whole) {
        Object.assign(this.getPrototype().getFormatter.call(this), formatter)
      }
      formatter = whole ? this.getPrototype().getFormatter.call(this) : formatter
      format(this.getProxy(), formatter, this.getSource())
      this.getPrototype().formatted.call(this, formatter)
      return this
    }

    /**
     * for override, invoke after format done
     */
    formatted(...args) {
      // app.logger.info("%c%s", "color: blue;", 'Model formatted:', arguments);
    }

    /** for override, watch data change */
    onUpdate(key, value, model, proxy) {
      // app.logger.info("%c%s", "color: red;", 'Model onUpdate:', arguments);
    }

    /** for override the onUpdate */
    addUpdateListener(func) {
      addUpdateListener(this, 'Update', func)
      return this
    }

    addFunction(funcName, func) {
      if (typeof funcName !== 'string' || typeof func !== 'function'
        || typeof this[funcName] !== 'function') {
        // app.logger.error('override ' + funcName + ' function failed.')
        return this
      }
      defineProperty(this, funcName, func, false)
      return this
    }

    /**
     * each every properties, the func returns false will continue next
     * @param {Function} func - function(key, value, Model) {}
     * @return {Model} this
     */
    each(func) {
      if (typeof func !== 'function') return
      for (let key in this) {
        if (this.hasOwnProperty(key)) {
          if (func.call(this, key, this[key], this) === false) {
            continue
          }
        }
      }
      return this
    }

    /**
     * reset value by key
     * @param {string} key
     * @param {*} value
     * @return {Model} this
     */
    set(key, value) {
      this.getProxy()[key] = value
      return this
    }

    add(key, value) {
      if (!this.hasOwnProperty(key)) {
        this.getPrototype().set.call(this, key, value)
      }
      return this
    }

    addAll(obj) {
      for (var key in obj) {
        this.add(obj[key])
      }
      return this
    }

    /**
     * input key or keys, return values
     * @param {...string} keys
     * @param {*} value
     * @return {Array} result
     */
    get([...keys]) {
      if (keys.length <= 1) {
        return this.getProxy()[keys]
      }
      let result = {};
      // keys.forEach(key => {
      //   result[key] = value === undefined ? '' : value;
      // })
      this.getPrototype().each.call(this, (key, value) => {
        if (keys.includes(key)) {
          result[key] = value === undefined ? '' : value;
        }
      })
      this.onUpdate(keys, result, this, this.getProxy())
      return result
    }

    /**
     * get value array by condition
     */
    getBy(func) {
      let result = []
      if (typeof func !== 'function') return
      this.getPrototype().each.call(this, (key, value) => {
        if (func.call(this, key, value, this) === true) {
          result.push(value)
        }
      })
      this.onUpdate(func, result, this, this.getProxy())
      return result
    }

    getLength() {
      return this.getPrototype().getKeys.call(this).length
    }

    empty() {
      this.getPrototype().each.call(this, (key) => {
        this.getPrototype().removeKey.call(this, key)
      })
      return this
    }

    getKeys() {
      return Object.keys(this)
    }

    getValues() {
      return Object.values(this)
    }
    getEntries() {
      return Object.entries(this)
    }

    hasKey(...keys) {
      if (keys === undefined) return false
      return keys.every((key) => {
        if (this.hasOwnProperty(key)) {
          return true
        }
        return false
      })
    }

    hasValue(...values) {
      if (values === undefined) return false
      let result
      return values.every((value) => {
        result = false
        this.getPrototype().each.call(this, (key, val) => {
          if (value === val) {
            result = true
            return
          }
        })
        return result
      })
    }

    hasKeyValue(key, value) {
      return (this[key] === value)
    }

    /**
     * remove this by function
     * @param {Function} func - function(key, value, Model)
     * @return {Model} this
     */
    removeBy(func) {
      if (typeof func !== 'function') return
      this.getPrototype().each.call(this, (key, value) => {
        if (func.call(this, key, value, this) === true) {
          delete this.getProxy()[key]
        }
      })
      return this
    }

    removeKey(...keys) {
      keys.forEach((key) => {
        delete this.getProxy()[key]
      })
      return this
    }

    removeValue(...values) {
      this.getPrototype().each.call(this, (key, value) => {
        if (values.includes(value)) {
          delete this.getProxy()[key]
        }
      })
      return this
    }

    /**
     * filter properties by function
     * @param {Function} func - function(key, value, Model)
     * @return {Model} copy
     */
    filter(func) {
      if (typeof func !== 'function') return
      let copy = this.getPrototype().clone.call(this)
      for (let key in copy) {
        if (func.call(copy, key, copy[key], copy) === true) {
          delete copy[key]
        }
      }
      return copy
    }

    /**
     * deep comparison by JSONStringify
     */
    equals(obj) {
      if (obj === this) {
        return true
      }
      if (typeof obj !== typeof this || obj === undefined || obj === null) {
        return false
      }
      if (Object.keys(obj).length !== this.getLength()) {
        return false
      }
      try {
        return this.toString() === JSON.stringify(obj)
      } catch (ex) {
        // app.logger.error(obj, this, ' equals error.')
        return false
      }
    }

    /**
     * shallow copy property
     */
    clone() {
      // return new (this.constructor)(this.toJSON())
      return new (this.constructor)(this)
    }

    toString() {
      try {
        return JSON.stringify(this.toPlain());
      } catch (e) {
        app.logger.error(e);
      }
    }

    /**
     * convert self and every Model/List property to plain objects
     */
    toPlain() {
      const result = {};
      for (var key in this) {
        if (this.hasOwnProperty(key)) {
          result[key] = this[key]
          if ((result[key] instanceof Model ||
            result[key] instanceof Array) &&
            (typeof result[key]).toPlain === 'function') {
            result[key] = (result[key]).toPlain()
          }
        }
      }
      return result;
    }

    toJSON() {
      try {
        return JSON.parse(this.toString());
      } catch (e) {
        app.logger.error(e);
      }
    }

    /**
     * creating temporary Model
     * @param {Object} props - { key: value }
     * @param {Object.<key, (value|Function|Array)} [formatter] - see format function
     * @param {Object.<key, Function>} [functions] - ovrride function list { name: function() {} }
     * @return {AnonymousModel} new anonymouse Model
     */
    static createModel(props, formatter, functions) {
      return class AnonymousModel extends Model {
        /**
         * constructor of the new anonymous Model
         * @param {Object.<key, value>} source
         * @param {Object.<key, (value|Function|Array)>} formula
         */
        constructor(source, formula) {
          super()
          super.define(props, source)
          for (var name in functions) {
            super.addFunction(name, functions[name])
          }
          super.init.call(this, source, Object.assign(formatter || {}, formula))
        }
      }
    }
  }
  return Model;
}


