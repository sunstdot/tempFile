class ApiError {
    constructor(opt) {
        this.type = opt.type || 'pcw-api';
        this.message = opt.msg || 'An error occured';
        this.detail = opt.detail || '';
        this.data = opt.data || ''; //用户可以看到的错误信息
        this.apiError = true;  //标记通用Error跟apiError
        Error.captureStackTrace(this,ApiError);
        this._stack = this.stack+'';
    }
}
module.exports = ApiError;
