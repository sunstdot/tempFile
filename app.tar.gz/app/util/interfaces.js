/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 * pcw-api idc机房列表如下
 * {
 *   "bjlt": "北京联通",
 *   "whdx": "武汉电信",
 *   "jyyd": "济阳移动",
 *   "bjdxt": "北京电信通",
 *   "bjyd": "北京移动",
 *   "bjdx": "北京电信"
 * }
 * 分机房接口配置，主要针对中间层的机房信息进行配置，接口配置优先级  同机房 > 同运营商 > 同地区 
 * 
 * @desc: interface module provide interface config
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 */
module.exports.albumInterface = { 'url': 'http://mixer.video.qiyi.domain/albums', 'timeout': 2000 };
module.exports.videoInterface = { 'url': 'http://mixer.video.qiyi.domain/mixin/videos', 'timeout': 2000 };
module.exports.videoQipuInterface = { 'url': 'http://qipu.qiyi.domain/video/getVideoBrief', 'timeout': 2000};   //奇谱新提供视频接口
module.exports.videoViewPointInterface = { 'url': 'http://10.153.148.182:7004', 'timeout': 2000 };  //获取视频看点接口
module.exports.videoSceneInterface = { 'url': 'http://10.153.148.182:7004', 'timeout': 2000 };  //获取视频场景接口
module.exports.resourceInterface = { 'url': 'http://mixer.video.iqiyi.com/mixin/resources', 'timeout': 2000 }; //资源位接口
module.exports.relatedStarInterface = { 'url': 'http://qipu.qiyi.domain/fusion/getRelatedInfoOfCelebrity', 'timeout': 3000 }; //qipu接口，获取相关明星
module.exports.relatedWorksInterface = { 'url': 'http://qipu.qiyi.domain/graph/getEntityInfo', 'timeout': 3000 }; //qipu接口，获取相关明星的作品
module.exports.bodanListInterface = { 'url': 'http://mixer.qiyi.domain/mixin/playlists', 'timeout': 2000 };  //bodanList接口
module.exports.qipuInterface = { 'url': 'http://qipu.qiyi.domain/fusion/getEntity', 'timeout': 3000 };  //qipu的fusion基础接口可定制返回的基本信息
module.exports.qipuEntityInterface = {'url': 'http://qipu.qiyi.domain/int/entity', 'timeout': 3000}; // qiyu entity
module.exports.categoryTreeByChannelIdInterface = { 'url': 'http://qipu.qiyi.domain/category/getCategoryTreeByChannelId', 'timeout': 2000 };  //qipu的根据频道ID获取分类列表树
module.exports.searchVideoListInterface = { 'url': 'http://search.video.qiyi.domain/o', 'timeout': 3000 }; //搜索方Onetree list接口
module.exports.videoInfoInterface = { 'url': 'http://mixer.video.iqiyi.com/mixin/videos', 'timeout': 2000 };
module.exports.qipuQueryTemplateInterface = {'url': "http://qipu.qiyi.domain/query/templateQuery", 'timeout': 3000};

module.exports.videoUpdownInterface = { 'url': 'http://bjdx.up.video.qiyi.domain/ugc-updown/quud.do', 'timeout': 3000};
module.exports.videoSubscribeInterface = {'url': 'http://pss.qiyi.domain/dingyue/api/areSubscribed.action', 'timeout': 3000};

module.exports.getNewestFeedsInterfaces = {
  url: 'http://api.t.qiyi.domain/feed/get_feeds',
  timeout: 10000
};

module.exports.myFavInterface = { 'url': 'http://pss.qiyi.domain/apis/watchlater/pcw/list.action', 'timeout': 2000 };  //收藏追剧接口
module.exports.ablumRcInterface = { 'url': 'http://l.rcd.qiyi.domain/apis/qiyirc/getalbumrcs', 'timeout': 3000 };  //通过专辑ID获取播放记录接口
module.exports.historyRcInterface = { 'url': 'http://l.rcd.qiyi.domain/apis/qiyirc/getUpdateReminder', 'timeout': 3000 };  //正在更新中的播放记录接口
module.exports.recommendInterface = { 'url': 'http://mixer.qiyi.domain/recommend/videos', 'timeout': 3000 };  //推荐猜你喜欢接口(电视剧和综艺通用)
module.exports.scoreInterface = { 'url': 'http://bjlt.score.video.qiyi.domain/beaver-api/get_user_multi_movie_score', 'timeout': 3000 };  //专辑视频评分接口


module.exports.hotshortvideoInterface = {'url':'http://api-top.qiyi.domain/index/hotshortvideo','timeout':2000}; //热门短视频排行榜接口
module.exports.playcountInterface = {'url':'http://bjct.cache.video.qiyi.domain/pc/','timeout':2000}; //播放数接口

module.exports.paoGetTopFeedsInterface = { url: 'http://api.t.qiyi.domain/feed/admin/get_top_feeds', 'timeout': 2000 }; // 获取置顶feed
module.exports.paoGetDefFeedsInterface = { url: 'http://api.t.qiyi.domain/feed/get_circle_def_feeds', timeout: 2000 }; // 查询圈子指定feed
module.exports.paoRecommendFoucsesInterface = {url: 'http://qiyu-jy.qiyi.domain/feed_stream/resys', timeout: 2000}; // 泡泡看点接口
module.exports.paoRecommendCirlcesInterface = {url:'http://qiyu.qiyi.domain/bubble/star_wall', timeout: 2000}; // 泡泡圈子推荐接口
module.exports.paoBatchFeedsInterface = {url: 'http://api.t.qiyi.domain/feed/admin/get_feeds_by_ids', timeout: 2000}; // 批量获取feed详情接口
module.exports.paoGetUserFeedsInterface = {url: 'http://api.t.qiyi.domain/feed/get_user_feeds', timeout: 2000}; // 获取用户feed流接口
// module.exports.paoBatchFeedsInterface = {url: 'http://10.221.84.71:8910/feed/admin/get_feeds_by_ids', timeout: 2000};
module.exports.paoInfluenceRankInterface = { url: 'http://paopao.qiyi.domain/apis/i/rank/DynamicInfluenceRank.action', timeout: 2000 }; // 明星影响力榜单
module.exports.paoBatchCircleBaseInfoInterface = { url: 'http://paopao.qiyi.domain/apis/i/starwall/wallBaseInfos.action', timeout: 2000 }; // 批量圈子基本信息接口
module.exports.paoStarWallInfo = { url: 'http://paopao.qiyi.domain/apis/e/starwall/home.action', timeout: 2000 }; // 获取单个明星圈子信息
module.exports.paoGetFeedsByQuery = {url: 'http://api.t.qiyi.domain/feed/admin/get_feeds_by_query', timeout: 2000}; // 按条件获取feed流
module.exports.paoGetFeeds = {url: 'http://api.t.qiyi.domain/feed/get_feeds', timeout: 2000}; // 获取feed流
module.exports.paoCircleTypeList = {url:'http://paopao.qiyi.domain/apis/i/starwall/wallTypeList.action', timeout: 2000}; // 泡泡圈子分类页接口
module.exports.userBasicInfoInterface = { 'url': 'http://passport.qiyi.domain/apis/inner/info/byUid.action', 'timeout': 3000 };  //获取单个用户基本信息接口
module.exports.usersBasicInfoInterface = { 'url': 'http://passport.qiyi.domain/apis/inner/info/batch/byUids.action', 'timeout': 3000 };  //批量获取用户基本信息接口
module.exports.userSnsInfoInterface = { 'url': 'http://passport.qiyi.domain/apis/friend/cntStat.action', 'timeout': 3000 };  //用户社交关系信息接口
module.exports.userVerifiesInfoInterface = { 'url': 'http://renzheng.qiyi.domain/services/verify/verifyInfos.htm', 'timeout': 3000 };  //批量获取用户加V信息接口
module.exports.userVerifyInfoInterface = { 'url': 'http://renzheng.qiyi.domain//services/verify/verifyInfo.htm', 'timeout': 3000 };  //单个获取用户加V信息接口
module.exports.userVipInfoInterface = { 'url': 'http://vinfo.vip.qiyi.domain/internal/vip_users', 'timeout': 3000 };  //用户vip信息接口
module.exports.userBusinessTypesInterface = { 'url': 'http://renzheng.qiyi.domain/services/allBusiness/queryBusinessTypes.htm', 'timeout': 5000 };  //用户业务列表接口

// http://wiki.qiyi.domain/pages/viewpage.action?pageId=155743484
module.exports.liveVideosInterface = {
  url: 'http://qipu.qiyi.domain/query/templateQuery',
  timeout: 3000
};

module.exports.userSubscribeInterface = { 'url': 'http://timeline.i.qiyi.domain/timeline-api/get_user_new_feed_num', 'timeout': 3000 }; // 用户订阅数更新接口
module.exports.userVipTVInterface = { 'url': 'http://bj.openapi.vip.qiyi.domain/present/qualification.action', 'timeout': 3000 }; // 用户获取vip电视果资格
module.exports.userTennisTVInterface = { 'url': 'http://bj.openapi.vip.qiyi.domain/buypresent/qualification.action', 'timeout': 3000 }; // 用户获取网球电视果资格
module.exports.userVerifyStatusInterface = {'url': 'http://passport.qiyi.domain/apis/user/verify_status.action', 'timeout': 3000};//查询用户实名验证状态
module.exports.userInfoInterface = {'url': 'http://passport.qiyi.domain/apis/user/info.action', 'timeout': 3000};//查询用户信息（安全接口）
module.exports.userPointsInterface = { 'url': 'http://community.iqiyi.com/openApi/user/info', 'timeout': 3000 };//查询用户积分信息
module.exports.userAutoRenewInterface = { 'url': 'http://serv.vip.iqiyi.com/services/directAutoRenew.action', 'timeout': 3000 };//查询用户自动续费信息
module.exports.userCouponInterface = { 'url': 'http://act.vip.iqiyi.com/marketing/coupon/getMessage.action', 'timeout': 3000 };//查询用户代金券信息

module.exports.albumUgcInterface = {'url': 'http://openapi.ugc.qiyi.domain/api/ugc/album', 'timeout': 3000};//保存播单信息||||||| .merge-left.r138469

module.exports.loginPlayRecordsInterface = {
    url: 'http://l.rcd.qiyi.domain/apis/qiyirc/getrc.php',
    timeout: 3000
};

module.exports.unloginPlayRecordsInterface = {
    url: 'http://nl.rcd.qiyi.domain/apis/urc/getrc',
    timeout: 3000
};

module.exports.userRecommendVideosInterface = {
  url: 'http://timeline.iqiyi.com/timeline-api/get_friends_recent_feeds',
  timeout: 3000
};

module.exports.recommendVideosInterface = {
  url: 'http://mixer.qiyi.domain/mixin/videos/users',
  timeout: 5000
};

module.exports.relationShipInterface = {
  url: 'http://sns.uc.qiyi.domain/apis/friend/are_friends.action',
  timeout: 3000
};

module.exports.userinfoFromMixerInterface = {
  url: 'http://mixer.qiyi.domain/users/info',
  timeout: 3000
};

module.exports.recommendUsersInterface = {
  url: 'http://qiyu.qiyi.domain/user',
  timeout: 3000
};

module.exports.userTimelineInterface = {
  url: 'http://timeline.i.qiyi.domain/timeline-api/get_user_timeline',
  timeout: 3000
};
// 追剧接口
module.exports.subscribeInterface = {
    areSubscribed: {
        url: 'http://pss.qiyi.domain/dingyue/api/areSubscribed.action',
        timeout: 3000
    }
};

// 奇异果领取资格检查
module.exports.qualificationInterface = {
    url: 'http://bj.openapi.vip.qiyi.domain/buypresent/qualification.action',
    timeout: 3000
};
// 奇异果领取记录检查
module.exports.getPresentInterface = {
    url: 'http://bj.openapi.vip.qiyi.domain/buypresent/isAlreadyGet.action',
    timeout: 3000
};
//龙源 tmpstats pingback投递地址
module.exports.tmpPingbackInterface = {
    url: 'http://msg.71.am/tmpstats.gif',
    timeout: 3000
};

//龙源 qya pingback投递地址
module.exports.qyaPingbackInterface = {
    url: 'http://msg.vip.iqiyi.com/qya.gif',
    timeout: 3000
};
//奇谱专辑影视原声接口
module.exports.albumSongsInterface = {
    url: 'http://qipu.qiyi.domain/video/getVideoBriefSongs?entity_id=206244101',
    timeout: 3000
};

//奇谱视频列表接口
module.exports.videoBriefListInterface = {
    url: 'http://qipu.qiyi.domain/video/getVideoBriefList',
    timeout: 3000
};
// 电影最新上线
module.exports.movieLastVideoInterface = {
  url: 'http://mixer.qiyi.domain/mixin/videos/movie/last',
  timeout: 3000
};

// 根据明星的奇谱ID获取相关作品
// http://wiki.qiyi.domain/pages/viewpage.action?pageId=21972067
module.exports.getRelatedVideosOfCelebrity = {
  url: 'http://qipu.qiyi.domain/fusion/getRelatedVideosOfCelebrity',
  timeout: 15000
}

// 获取明星推荐视频
module.exports.tagcategoryvideos = {
  url: 'http://qiqu.qiyi.domain/apis/tagcategoryvideos',
  timeout: 3000
}

//推荐接口
module.exports.resys30RecommendVideoInterface = {
  url: 'http://qiyu.qiyi.domain/resys30',
  timeout: 3000
}
module.exports.p13n20RecommendVideoInterface = {
  url: 'http://qiyu.qiyi.domain/p13n20',
  timeout: 3000
}//分机房接口配置,有机房域名的走机房域名，没有机房域名的走默认 'default'
const interfaceConfig = {
  videoScoreInterface: { 
    'default': 'http://score.bi.qiyi.domain/soya/get_user_movie_score', 
    'bjdx': 'http://bjdx.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'bjlt': 'http://bjlt.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'jyyd': 'http://jyyd.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'bjdxt': 'http://bjdxt6.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'timeout': 2000 
  }
};

//获取接口
module.exports.getInterface = (name) => {
  let inter = interfaceConfig[name];
  if(!idc || !inter[idc]) {
    url = inter.default;
  }else {
    url = inter[idc];
  }
  return {
    url,
    timeout: inter.timeout
  };
}

