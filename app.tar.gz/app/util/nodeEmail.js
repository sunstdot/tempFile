'use strict';
/**
 * Copyright 2018 Qiyi Inc. All rights reserved.
 *
 * @desc: 发送邮件模块
 * @author: sunshitao@qiyi.com
 * @date:   2018-07-30
 */
const fs = require('fs');
var nodemailer = require('nodemailer');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

function write(msg) {
  let htmlContent = `
    <html>
      <head>
        <style>
          body {
            font-size: 16px;
            font-weight: bolder;
          }
          tr {
            border: 1px solid;
            font-size: 16px;
            font-weight: bolder;
          }
          td {
            border: 1px solid;
            font-size: 16px;
            font-weight: bolder;
          }
          theader {
            background-color: #CDC9C9;
          }
        </style>
      </head>
      <body>
        <div style="margin-top:20px; font-size:18px;">${msg}</div>
      </body>
    </html>
  `;
  let htmlFileDir = '/data/alertmail/';
  // if(!fs.existsSync(htmlFileDir)) {
  //   fs.mkdirSync(htmlFileDir);
  // }
  let htmlfile = htmlFileDir+'alert.html';
  // fs.writeFileSync(htmlfile, htmlContent, 'utf-8');
  return htmlContent;
}


var transporter = nodemailer.createTransport({
    "host": '10.121.86.154',
    "port": 25,
    "secure": false,
    "auth": {
        "user": 'pcw-mail@mams.iqiyi.domain', // user name
        "pass": 'fn&f$d#35'         // password
    }
});
// transporter.verify(function(error, success) {
//   if(error) {
//     console.log(error);
//   }else {
//     console.log('server is ready');
//   }
// });

async function sendmail(options){
  return new Promise((resolve, reject) => {
    transporter.sendMail(options, function(error, info){
      if(error){
        console.log(error)
        resolve({type:'failed'});
        return;
      }else {
        console.log('mail send success');
        resolve({type: 'success'});
      }
    });
  });
}

//发送邮件
class nodeEmail {
  static async send(addr, msg, title = '中间层错误率报警') {
    if(!addr){
      return;
    }
    console.log(addr+'===========');
    let htmlContent = write(msg);
    var mailOptions = {
      from: 'pcw-mail@mams.iqiyi.domain', // sender address mailfrom must be same with the user
      to: addr, // list of receivers
      subject: title, // Subject line
      text: 'errorrate test', // plaintext body
      html: htmlContent,
    };
    console.log('start sending:....')
    return await sendmail(mailOptions);
  }
}

module.exports = nodeEmail;