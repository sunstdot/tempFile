'use strict';
const IsType = require('./util').IsType;

/**
 * @desc 分页功能
 * @author zhanghao
 * @version 1.0 2018/01/10
 * 
 * @param {object} opt 配置参数
 * @param {array} opt.list 需要分页的数组（默认[]）
 * @param {number|string} opt.page 页码（默认1）
 * @param {number|string} opt.size 每页记录数 （默认10）
 * @return {object} 分页结果
 */
exports.limitPage = function (opt) {
    let {
        list,
        page,
        size
    } = opt;
    list = IsType.isArray(list) ? list : [];
    page = page <= 0 ? 1 : page;
    size = size <= 0 ? 10 : size;
    const pageInfo = {
        list: [],
        total: list.length,
        page: parseInt(page, 10),
        size: parseInt(size, 10),
        totalPage: 0,
        remaining: 0
    };
    pageInfo.totalPage = Math.ceil(pageInfo.total / pageInfo.size);
    if (pageInfo.page <= pageInfo.totalPage) {
        const startIdx = (page - 1) * size,
            endIdx = Math.min(page * size, pageInfo.total);
        for (let i = startIdx; i < endIdx; i++) {
            pageInfo.list.push(list[i]);
        }
    }
    if(pageInfo.page < pageInfo.totalPage) {
        pageInfo.remaining = 1;
    }
    else {
        pageInfo.remaining = 0;
    }
    return pageInfo;
}