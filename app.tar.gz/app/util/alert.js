'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc:   对接报警平台发送post请求
 * @author: sunshitao@qiyi.com
 * @date:   2017-11-29
 * 
 * @version 1.0.1 对MAC系统进行兼容 zhanghao 2017/12/28
 */
let os = require('os');
const request = require('request');
const secret_key = 'd81c9d23-0a2e-4e11-9c69-f5d9a68174be';
const alertUrl = 'http://alert.qiyi.domain/event/create/';
let host = "127.0.0.1";
//不同系统os.networkInterfaces()获取内容不同，需要区分
let platform = os.platform();
if(platform !== "win32") {
    const items = os.networkInterfaces().eth0 || os.networkInterfaces().lo0 || os.networkInterfaces().en0 || [];
    for(var i = 0; i < items.length; i++){
        if(items[i].family == 'IPv4'){
            host = items[i].address;
        }
    }
}

function postAlert(topicId, data) {
    let param = {
        topic_id: topicId,
        secret_key,
        data:JSON.stringify(data)
    };
    request.post({url:alertUrl, form: param}, function(err, httpResponse, body) {        
    });
}

class Alert {
    //中间层接口code异常报警
    static interfaceCodeAlert(param) {
        const {url, code, requestId, detail} = param;
        const topicId = 1294;
        const data = {
            url,
            host,
            code,
            requestId,
            detail
        };
        postAlert(topicId, data);
    }
}

module.exports = Alert;