/**
 * @fileOverview 视频相关的util
 */

'use strict';

exports.PAYMARK = {
    'NONE_MARK': 0,
    'VIP_MARK': 1,
    'PAY_ON_DEMAND_MARK': 2,
    'COUPONS_ON_DEMAND_MARK': 3,
    'PAY_MARK_TENNIS_VIP_MARK': 4,
    'PAY_MARK_TENNIS_PAY_ON_DEMAND_MARK': 5,
    'PAY_MARK_TENNIS_COUPONS_ON_DEMAND_MARK': 6
};