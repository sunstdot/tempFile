'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: 封装统计中间层日志个数类api
 * @author: sunshitao@qiyi.com
 * @date:   2018-07-10
 */

const elasticsearch = require('elasticsearch')
const BigNumber = require('bignumber.js');
let client = new elasticsearch.Client({
    host: 'http://pcw-node-server-elasticsearch-online005-bdyf.qiyi.virtual:9200'
})
// const {getAllPath} = require("./config/interface");

const codeArr = ["A00001", "A00002", "A00003", "A00004"];
const hostArr = ['10.13.38.134', '10.13.38.135', '10.13.40.166','10.13.40.165','10.13.44.106',
    '10.13.44.107', '10.13.44.108', '10.127.18.156', '10.127.18.157', '10.127.20.24', '10.153.164.14',
    '10.153.164.15', '10.16.84.203', '10.15.246.57', '10.16.85.209', '10.16.165.246', '10.16.165.247',
    '10.12.18.78', '10.12.18.79', '	10.12.18.63', '	10.12.18.67', '10.110.87.78', '10.110.87.79', '10.110.87.80'];
//昨天的时间
let yesterdayStartTime = new Date(new Date().setHours(0, 0, 0, 0)).getTime() - 86400000;
let yesterdayEndTime = yesterdayStartTime + 86399999;


//最近60分钟的时间
let fiftyEndTime = new Date().getTime();
let fiftyStartTime = fiftyEndTime - 60*60000;

// let endTime = new Date().getTime() - 3600;
let nginxIndex = "auto-pcw_node_log_online_pcw_nginx_log_online-*";
let nodeIndex = "auto-pcw_node_log_online_pcw_node_log_online-*";

//nginx日志的数量
let nginxCount = {
    "match_all": {}
};
//node日志的数量
let nodeCount = {
    "match_all": {}
};
//node错误日志的数量
let nodeErrorCount = {
    "match": {
        "@fields.module": "errorHandler"
    }
};

/**
 * 根据api路径分割api
 * @param {*} api 接口path
 */
function seperateRoute(api) {
    let arr = [];
    if(api.includes(":")) {
        while(api.includes(":")) {
            let index = api.indexOf(":");
            let apiseq = api.slice(0,index);
            api = api.slice(index+1);
            arr.push(apiseq);
            let index1 = api.indexOf("/");
            if(index1 >= 0) {
                api = api.slice(index1+1);
            }else {
                api = "";
            }

        }
    }
    if(api) {
        arr.push(api);
    }
    return arr;
}

//------------------------------一级接口------------------------------------------------------------------
//获取一段时间某类型的总日志数
async function getTimeRangeTotalCount(param,index, startTime, endTime) {
    let {count} = await client.count({
        "index": index,
        "body": {
            "query": {
                "bool": {
                    "must": [
                        ...param,
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": startTime,
                                    "lte": endTime,
                                    "format": "epoch_millis"
                                }
                            }
                        }],
                    "filter": [],
                    "should": [],
                    "must_not": []
                }
            }
        }
    });
    return count;
}

class StatisticsCount {
  //获取一段时间node总日志数
  static async getNodeTotalCount(startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [{
        "match": {
            "@fields.module": "timeStatistics"
        }
    }];
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }
  //获取nginx pv日志数,默认获取一天的日志数
  static async getNginxTotalCount(startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let count = await getTimeRangeTotalCount([], nginxIndex, startTime, endTime);
    return count;
  }
  // static async getNginxTotalCount(startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
  //   let count = 0;
  //   let routeConf = await getAllPath();
  //   let promises = routeConf.map(async api => {
  //       return await getApiNginxCount(api, startTime, endTime);
  //   });
  //   let testList = await Promise.all(promises);
  //   count = testList.reduce((total, num) => {
  //       return total + num;
  //   },0);
  //   return count;
  // }

  //获取一段时间node日志出错的总数量
  static async getErrorNodeTotalCount(startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [{
        "match": {
            "@fields.module": "errorHandler"
        }
    }];
    let count  = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }

  //获取中间层某接口一段时间的nginx日志数
  static async getApiNginxCount(api, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let arr = seperateRoute(api);
    let message = "";
    for(let i=0, len = arr.length ;i<len;i++) {
        let item = arr[i];
        message += `@message:\"${item}\"`;
        if(i<(len-1)) {
            message += " AND ";
        }
    }
    let param = [{
        "query_string": {
            "query": message,
            "analyze_wildcard": true,
            "default_field": "*"
        }
    }];
    let count = await getTimeRangeTotalCount(param, nginxIndex, startTime, endTime);
    return count;
  }
  //获取中间层某接口一段时间的node访问日志数
  static async getApiNodeCount(api, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [
        {
            "query_string": {
                "query": `@fields.api: \"${api}\" AND @fields.module:\"timeStatistics\"`,
                "analyze_wildcard": true,
                "default_field": "*"
            }
        }
    ];
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }
  //获取中间层某接口一段时间错误node日志数
  static async getApiErrorNodeCount(api, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [
        {
            "query_string": {
                "query": `@fields.api: \"${api}\" AND @fields.module:\"errorHandler\"`,
                "analyze_wildcard": true,
                "default_field": "*"
            }
        }
    ]
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }
  //获取中间层某host的一段时间的请求数
  static async getHostNginxCount(host, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [{
        "match": {
            "@fields.host": host
        }
    }];
    let count = await getTimeRangeTotalCount(param, nginxIndex, startTime, endTime);
    return count;
  }
  //获取中间层某host的一段时间的请求数
  static async getHostNodeCount(host, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [{
        "match": {
            "@fields.host": host,
            "@fields.module": "timeStatistics"
        }
    }];
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }
  //获取中间层某host某api的nginx请求
  static async getHostApiNginxCount(api, host, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [{
        "query_string": {
            "query": `@message: \"${api}\" AND @fields.host:\"${host}\"`,
            "analyze_wildcard": true,
            "default_field": "*"
        }
    }];
    let count = await getTimeRangeTotalCount(param, nginxIndex, startTime, endTime);
    return count;
  }
  //获取中间层某host某api的node请求数
  static async getHostApiNodeCount(api, host, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [{
        "query_string": {
            "query": `@fields.api: \"${api}\" AND @fields.module:\"timeStatistics\" AND @fields.host:\"${host}\"`,
            "analyze_wildcard": true,
            "default_field": "*"
        }
    }];
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }
  //获取中间层某host某api的node错误请求数
  static async getHostApiNodeErrorCount(api, host, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [
        {
            "query_string": {
                "query": `@fields.api: \"${api}\" AND @fields.module:\"errorHandler\" AND @fields.host:\"${host}\"`,
                "analyze_wildcard": true,
                "default_field": "*"
            }
        }
    ];
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }
  //获取某接口某类型错误数
  static async getApiNodeCodeErrorCount(api, code,startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [
        {
            "query_string": {
                "query": `@fields.api: \"${api}\" AND @fields.module:\"errorHandler\" AND @fields.apiCode:\"${code}\"`,
                "analyze_wildcard": true,
                "default_field": "*"
            }
        }
    ];
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }
  //获取某接口某类型某host上的错误数
  static async getHostApiNodeCodeErrorCount(api, code, host, startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let param = [
        {
            "query_string": {
                "query": `@fields.api: \"${api}\" AND @fields.module:\"errorHandler\" AND @fields.apiCode:\"${code}\" AND @fields.host:\"${host}\"`,
                "analyze_wildcard": true,
                "default_field": "*"
            }
        }
    ];
    let count = await getTimeRangeTotalCount(param, nodeIndex, startTime, endTime);
    return count;
  }

//=================================错误率类接口===================================================
  //获取某接口一段时间的错误率
  static async getApiNodeErrorRate(api,startTime = fiftyStartTime, endTime = fiftyEndTime) {
    let totalCount = await this.getApiNginxCount(api, startTime, endTime);
    let errorCount = await this.getApiErrorNodeCount(api, startTime, endTime);
    totalCount = new BigNumber(totalCount);
    errorCount = new BigNumber(errorCount);
    console.log('总的请求数====='+totalCount+'总的错误数======'+errorCount+'\n\r');
    let result = totalCount == 0 ? 0 : errorCount.dividedBy(totalCount).multipliedBy(100).toFixed(4);
    return result;
  }
  //获取某接口某种code类型 一段时间的错误率
  static async getApiCodeNodeErrorRate(api, code, startTime = fiftyStartTime, endTime = fiftyEndTime) {
    let totalCount = await this.getApiNginxCount(api, startTime, endTime);
    let errorCount = await this.getApiNodeCodeErrorCount(api, code, startTime, endTime);
    errorCount = new BigNumber(errorCount);
    totalCount = new BigNumber(totalCount);
    console.log(`${code}的请求数=====`+totalCount+'总的错误数======'+errorCount+'\n\r');
    let result = totalCount == 0 ? 0 : errorCount.dividedBy(totalCount).multipliedBy(100).toFixed(4);

    return result;
  }
  //获取某接口在某host上一段时间的错误率
  static async getHostApiNodeErrorRate(api, host, startTime = fiftyStartTime, endTime = fiftyEndTime) {
    let totalCount = await this.getHostApiNginxCount(api, host,startTime, endTime);
    let errorCount = await this.getHostApiNodeErrorCount(api, host, startTime, endTime);
    totalCount = new BigNumber(totalCount);
    errorCount = new BigNumber(errorCount);

    console.log('总的请求数====='+totalCount+'总的错误数======'+errorCount+'\n\r');
    return totalCount == 0 ? 0 : errorCount.dividedBy(totalCount).multipliedBy(100).toFixed(4);
  }
  //获取某接口在某host上某code类型一段时间的错误率
  static async getHostApiCodeNodeErrorRate(api, host, code, startTime = fiftyStartTime, endTime = fiftyEndTime) {
    let totalCount = await this.getHostApiNginxCount(api, host,startTime, endTime);
    let errorCount = await this.getHostApiNodeCodeErrorCount(api,code, host, startTime, endTime);
    console.log(`${code}的请求数=====`+totalCount+'总的错误数======'+errorCount+'\n\r');
    totalCount = new BigNumber(totalCount);
    errorCount = new BigNumber(errorCount);
    return totalCount == 0 ? 0 : errorCount.dividedBy(totalCount).multipliedBy(100).toFixed(4);
  }
  //获取各个host一段时间的Nginx数
  static async getAllHostNginxCount(startTime = yesterdayStartTime, endTime = yesterdayEndTime) {
    let promises = hostArr.map(async host => {
        let count = await getHostNginxCount(host, startTime, endTime);
        return {
            'host':count
        };
    });
    let hostCountList = Promise.all(promises);
    return hostCountList;
  }
  //获取一段时间的各个接口错误率
  static async getTimeRangeApiErrorRate(startTime = fiftyStartTime, endTime = fiftyEndTime) {
    if(startTime > endTime) {
        return '时间输入有误';
    }
    let routeConf = await getAllPath();
    let temp = {};
    let promises = routeConf.map(async api => {
        let nginxCount = await getApiNginxCount(api, startTime, endTime);
        let errorCount = await getApiErrorNodeCount(api, startTime, endTime);
        nginxCount = new BigNumber(nginxCount);
        errorCount = new BigNumber(errorCount);
        temp[api] = errorCount.dividedBy(nginxCount).multipliedBy(100).toFixed(4);
    })
    let rateList = Promise.all(promises);
    return rateList;
  }
  //获取一段时间内某接口某host的错误率
  static async getTimeRangeApiHostErrorRate(api, host, startTime = fiftyStartTime, endTime = fiftyEndTime) {
    return getHostApiNodeErrorRate(api, host, startTime, endTime);
  }
}

module.exports = StatisticsCount












