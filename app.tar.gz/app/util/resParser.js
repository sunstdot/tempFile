const PARSER_BASE = {};
function register(str, handler){
    if(typeof handler === "function"){
        PARSER_BASE[str] = handler;
    }
}

/**
 * 返回内容
 * @param {String} body response body 
 * @param {String|Function} [parser] 默认是
 * @throws 跑出parser异常。
 */
module.exports.parse = function(body, parser){
    let parseType = typeof parser,
        commonType = JSON.parse;
    if(parseType === "string"){
        commonType = PARSER_BASE[parser] || "json";   
    }
    else  if(parseType === "function"){
        return parser(body);
    }
    return commonType(body);
}

module.exports.register = register;

const SEARCH_MAX = 50;
register("jsonp", function(result){
    let start = 0;
    let length = result.length;
    let end = length - 1;
    let isWithTry = false;

    while(start <= SEARCH_MAX && start < length){
        if(result.charAt(start) === '['){
            break;
        }
        else if(result.charAt(start) === '{'){
            let sub = result.substring(0, start);
            if(isWithTry){
                break; 
            }
            else if(sub.indexOf("try") != -1){
                isWithTry = true;
            }
        }
        start ++;
    }
    while(end >= length - SEARCH_MAX && end > start){
        if(result.charAt(end) === ']'){
            break;
        }
        else if(result.charAt(end) === '}'){
            if(isWithTry){
                let sub = result.substring(end);
                // try {} catch(e){} module
                // try {} catch(e){} finally{} module
                if(/\}\s*catch/g.exec(sub)){
                    isWithTry = false;
                }
                // TODO try {} finally{} module, most jsonp would not like this,
                // so implement when encounted.
            }
            else{
                break;
            }
        }
        end --;
    }
    let subString = result.charAt(start) + result.charAt(end);
    let finalString = null;
    if(subString === "{}" || subString === "[]"){
        // json 
        finalString = result.substring(start, end + 1);
        try{
            return JSON.parse(finalString);
        } catch(e){
            let tmpFunction = new Function(`return ${finalString}`);
            return tmpFunction.call();
        }
    }
    else{
        // not json, set it as a string.
        // replace " to ', \r and \n to empty.
        return  "'" + result.replace(/\'/gi, "\"").replace(/\r|\n/gi, '') + "'";
    }
    return {};
});