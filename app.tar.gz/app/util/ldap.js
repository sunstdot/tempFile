/**
 * Copyright 2018 Qiyi Inc. All rights reserved.
 * @desc: 封装权限认证模块
 * @author: sunshitao@qiyi.com
 * @date:   2018-07-31
 */
const ldap = require('ldapjs');

async function loginLdap(username, password) {
  return new Promise((resolve, reject) => {
    let client = ldap.createClient({
      url: 'ldap://10.11.50.65:389'
    });
    client.bind('iqiyi\\' + username, password, function(err) {
      if(err) {
        resolve({type: 'failed'});
        return;
      }else {
        resolve({type: 'success'})
        return;
      }
    })
  })
}

module.exports = loginLdap;