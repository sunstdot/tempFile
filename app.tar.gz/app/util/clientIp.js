"use strict";
/**
 * Copyright 2018 Qiyi Inc. All rights reserved.
 *
 * @desc:   中间层接口获取客户端ip
 * @author: jiayanqi_sx@qiyi.com
 * @date:   2018-01-22
 */
const clientIp = {
    getClientIp(req) {
        let ip = req.headers['x-forwarded-for'] ||
                       req.connection.remoteAddress ||
                       req.socket.remoteAddress ||
                       (req.connection.socket ? req.connection.socket.remoteAddress : null);
        let ipNum = ip.split(':');
        let realIp = ipNum[ipNum.length-1].split(',');
        return realIp[0];
    }
};
module.exports = clientIp;
