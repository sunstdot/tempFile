/**
 * Copyright (C) 2018 iQIYI (www.iqiyi.com).
 * All Rights Reserved.
 * @desc: model基类的lib库
 * @function:
 * - basic Model for data Model inheritance
 * - define data properties and formatter
 * - watching data change from Proxy
 * @author: lichunping@qiyi.com, sunshitao@qiyi.com
 * @date: 2018-05-15
 */
const { is } = require('./util').IsType
const isObject = is('Object')
const isModel = is('Model')

module.exports.defineProperty = function(obj, key, val, enumerable, config) {
  Object.defineProperty(obj, key, Object.assign({
    value: val,
    enumerable: !!enumerable,
    writable: true,
    configurable: true
  }, config))
}

module.exports.format = function(model, formatter, source = {}) {
  if (!isObject(formatter)) {
    pcwApp.logger.warn('formatter is no an object.');
    return;
  }
  for (let key in formatter) {
    if (Array.isArray(formatter[key])) {
      let target = source
      for (let next of formatter[key]) {
        target = target[next]
        if(!target) {
          target = '';
          break;
        }
      }
      model[key] = target
    } else {
      let value = formatter[key]
      model[key] = (typeof formatter[key] === 'function') ?
        (formatter[key]).call(model, source, model, formatter) :
        source[value] || model[key];
    }
  }
  return model
}

module.exports.addUpdateListener = (obj, evt, func) => {
  defineProperty(obj, 'on' + evt, func, false)
}

module.exports.observeObject = function(object) {
  function createProxy(prefix, object) {
    return new Proxy(object, {
      set: (target, property, value, receiver) => {
        if (typeof property === 'symbol') {
          return true
        }
        let getter = property && property.get
        let setter = property && property.set
        value = getter ? getter.call(this) : value
        target[property] = value
        object.onUpdate.call(object, prefix + property, value, target, receiver)
        return true
      },

      get: (target, property, receiver) => {
        let getter = property && property.get
        let setter = property && property.set
        let value = getter ? getter.call(this) : target[property]
        if (isObject(value) && object.hasOwnProperty(value)) {
          return createProxy(prefix + property + '.', value)
        } else {
          return value
        }
      }
    })
  }

  return createProxy('', object)
}