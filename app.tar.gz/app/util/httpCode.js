/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: http code module provide http code config
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-12
 */
const codeMsg = {
    'success':{
        code:'A00000',
        data:'请求成功'
    },
    'arg_error':{
        code:'A00001',
        data:'参数错误'
    },
    'not_found':{
        code:'A00002',
        data:'未找到数据'
    },
    'request_failed': {
        code: 'A00003',
        data: '请求失败,请重试'
    },
    'internal_error': {
        code: 'A00004',
        data: '服务端错误'
    },
    'timeout_error': {
        code: 'E00000',
        data: '接口超时'
    },
    'access_deny': {
        code: 'A00005',
        data: '禁止访问'
    }
};

const statusMsg = {
    'success': {
        status:200
    },
    'access_deny': {
        status: 401
    },
    'arg_error': {
        status:406
    },
    'not_found': {
        status:404
    },
    'request_failed': {
        status:504
    },
    'internal_error': {
        status:500
    },
    'timeout_error': {
        status:504
    }
};

module.exports.httpCode = (type,data) => {
    return Object.assign({}, codeMsg[type], data ? { data } : {});
};

module.exports.httpMsg = (type) => {
    return codeMsg[type];
};

module.exports.httpStatus = (type) => {
    return statusMsg[type];
};
