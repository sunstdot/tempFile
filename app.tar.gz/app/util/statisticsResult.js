'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: 封装统计中间层日志结果类api
 * @author: sunshitao@qiyi.com
 * @date:   2018-07-20
 */
const elasticsearch = require('elasticsearch')
let client = new elasticsearch.Client({
    host: 'http://pcw-node-server-elasticsearch-online005-bdyf.qiyi.virtual:9200'
});
//昨天的时间
let yesterdayStartTime = new Date(new Date().setHours(0, 0, 0, 0)).getTime() - 86400000;
let yesterdayEndTime = yesterdayStartTime + 86399999;


//最近15分钟的时间
let fiftyEndTime = new Date().getTime();
let fiftyStartTime = fiftyEndTime - 15*60000;
const accuracy = 15;

let nginxIndex = "auto-pcw_node_log_online_pcw_nginx_log_online-*";
let nodeIndex = "auto-pcw_node_log_online_pcw_node_log_online-*";

//============================基础查询函数=================================
async function getTimeRangeResult(param, index, startTime, endTime) {
  let response = await client.search({
    "index": index,
    "body": {
        "query": {
            "bool": {
                "must": [
                    param,
                    {
                        "range": {
                            "@timestamp": {
                                "gte": startTime,
                                "lte": endTime,
                                "format": "epoch_millis"
                            }
                        }
                    }],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }
  });
  return response;
}
class StatisticsResult {
  // 查询node api一段时间的结果
  static async queryTimeRangeApiResult (api, type, startTime, endTime, host) {
    let serviceParam = this.serviceChoose(api, type, host);
    let param = {
      "query_string": {
        "query": serviceParam.query,
        "analyze_wildcard": true,
        "default_field": "*"
      }
    };
    let timeRange = (endTime - startTime) / accuracy;
    let result = [];
    for (let i = 0; i < accuracy; i++) {
      result[i] = await getTimeRangeResult(param, serviceParam.index, startTime, startTime + timeRange);
      startTime+=timeRange;
    }
    return result;
  }
  // 获取es查询条件
  static serviceChoose (api, type, host) {
    let query = ``;
    let index = "";
    if (type == 'Node') {
      query = `@fields.api:\"${api}\" AND @fields.module:\"timeStatistics\"`;
      index = nodeIndex;
    } else if (type == 'Nginx') {
      api = api.split(':')[0];
      //query = `@message:\"${api}\"`;
      query = `@fields.requestUrl:\"${api}\"`;
      index = nginxIndex;
    }
    if (host != 'All') {
      let hostQuery = ` AND @fields.host:\"${host}\"`;
      query+=hostQuery;
    }
    return {query, index};
  }
}
module.exports = StatisticsResult;