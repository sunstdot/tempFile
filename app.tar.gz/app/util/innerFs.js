'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: internal module provide node api package for app
 * 封装node api的fs方法
 * @author: sunshitao@qiyi.com
 * @date:   2018-02-26
 */
const fs = require('fs');

class fsApi {
    static async readFile(dir) {
        return new Promise((resolve, reject) => {
            fs.readFile(dir, 'utf-8', (err,data) => {
                if(err) {
                    resolve(err);
                }
                resolve(data);
            })
        }); 
    }

    static async writeFile(dir, data) {
        return new Promise((resolve, reject) => {
            fs.writeFile(dir, data, 'utf-8', (err) => {
                if(err) {
                    resolve(err);
                }
                resolve('success');
            })
        })
    }
}

module.exports = fsApi