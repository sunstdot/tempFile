'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 * test app
 * @desc: app module extends frameWork
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 */
const FrameWork = require("qiyi-wings");
// 上线打包时根据需要可新增一个版本, 版本号规则4位，x.x.xx
const VERSION = '1.0.20';
// 上线部署时自动更新一个发布时间
const PUBLISH_TIME= '201712251630';
class App extends FrameWork{
    constructor(opt) {
        super(opt)
    }

    get version() {
        return VERSION;
    }

    get publish() {
        return PUBLISH_TIME;
    }
}

module.exports = App;
