'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: albums dao module request album info
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 */
let pathInterface = {
    url: "http://pcw-api.qiyi.domain/allpath",
    timeout: 3000
}
module.exports = app => {
    class AlbumDao extends app.Dao {
        constructor(ctx) {
            super(ctx);
        }
        async getAllPath() {
            let infoData = await this.requestGet(pathInterface.url, pathInterface.timeout);
            return infoData.data.data;
        }
        async getAllClass() {
            let infoData = await this.getAllPath();
            for (let i = 0; i < infoData.length; i++) {
                infoData[i] = infoData[i].split('/')[1] || '/';
            }
            return Array.from(new Set(infoData));
        }

    }
    return AlbumDao;
};
