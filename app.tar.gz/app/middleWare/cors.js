/**
 * @fileOverview :支持cors
 * @author zhaorui
 * @date 2018.03.23
 */

'use strict';

module.exports = () => {
    return async (ctx, next) => {
        const env = process.env.NODE_ENV;
        const envEnableCors = ['test', 'development'];
        const whitelist = [
            'http://main.iqiyi.com:9090',
            'http://www.iqiyi.com',
            'https://www.iqiyi.com'
        ];
        const requestOrigin = ctx.accept.headers.origin;
        ctx.set({
            'Access-Control-Allow-Origin': requestOrigin,
            'Access-Control-Allow-Credentials': true,
            // 'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Methods': 'PUT,POST,GET',
        });
        await next();
    }
}