'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: error handler middleware 错误处理中间件
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-20
 * @version 1.0.1 添加LogItem日志格式类 by zhanghao on 20170520
 */

const {httpCode, httpStatus} = require('../util/httpCode');
const {LogItem} = require('../util/logItem');
const Alert = require('../util/alert');

module.exports = () => {
    return async (ctx,next) => {
        let startTime = (new Date()).getTime();

        try {
            await next();
        }catch(err) {
            let errType = err.type || 'internal_error';
            if(!err.type) {
                let errObj = {};
                errObj.__stack = err.stack + '';
                errObj.message = err.message;
                err = errObj;
            }
            let data = err.data || ''; //暴露给用户的报错信息
            let status = 200;
            let body = httpCode(errType,data);
            ctx.body = body;
            ctx.status = status;         //node服务正常的情况下，状态码均为200
            /*------------------错误日志打印----------------------------*/
            let url = ctx.path;
            let routeUrl = ctx._matchedRoute;
            let query = ctx.query || {};
            let param = Object.assign(ctx.params, query);
            let totalTime = (new Date()).getTime() - startTime;
            let logItem = new LogItem({
                api: routeUrl,
                apiTime: totalTime,
                apiParam: param,
                apiStatus: status,
                apiCode: body.code,
                requestId: ctx.requestId,
                referer: ctx.request.header.referer  || query.referer,
                error: err
            });
            pcwApp.logger.error(`[request ${url} error]`, logItem);
            /*------------------错误日志报警投递----------------------------*/
            let code = body.code;
            let detail = JSON.stringify(err);
            if(routeUrl !== "/subscribe/subscription/tonglan-updates") {
                Alert.interfaceCodeAlert({url: routeUrl, code, requestId: ctx.requestId, detail});
            }
        }
    };
};
