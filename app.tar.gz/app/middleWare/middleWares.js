/**
 * @desc: 中间件配置文件 对应各中间件写法为koa2的形式
 * @author: kexu@qiyi.com
 * @date:   2017-09-12
 */
const compose = require('koa-compose');
const errorHandler = require('./errorHandler')();
const jsonp = require('./jsonp')();
const validateParams = require('./validateParams')();
const timeStatistics = require('./timeStatistics')();
const ipControl = require('./ipcontrol')();
const bodyParser = require('./bodyParser')();
const cors = require('./cors')();
const middleWares = compose([errorHandler, cors, bodyParser,validateParams, timeStatistics]);
const innerMiddleWares = compose([errorHandler, bodyParser,validateParams, timeStatistics]);
const internalMiddleWares = compose([errorHandler, jsonp, bodyParser,ipControl, timeStatistics]);
async function last(ctx, next) {
    //do sth
    await next();
}
//自定义中间件使用
const customMiddleWares = compose([middleWares, last]);


module.exports = {
    commonMiddleWares: middleWares,
    commonInnerMiddleWares: innerMiddleWares,
    internalMiddleWares
};