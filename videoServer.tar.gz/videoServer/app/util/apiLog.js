'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc:   记录log
 * @author: kexu@qiyi.com
 * @date:   2017-07-28
 * @version 0.2  by sunshitao 增加warnLog方法，封路infoLog功能,可以直接调用此方法打印对应日志
 */

const {LogItem} = require('./logItem');
const ApiError = require('./apiError');
const ApiLog = {
    errorLog(opt) {
        let error = new ApiError(opt.error || {});
        let errObj = new LogItem(Object.assign(opt,{error}));
        pcwApp.logger.error(`[error trigger in ApiLog]`, errObj);
    },
    /**
     * 打印日志信息
     * @param {*} message
     * @param {*} opt
     */
    infoLog(message, opt = {}) {
        const request = ctx.request;

        let url = request.path;
        let routeUrl = request._matchedRoute;
        let params = request.params || {};
        let query = request.query || {};
        options.param = Object.assign(params, query);
        options.requestUrl = routeUrl || url;
        let options = {
            api
        };
        let infoObj = new LogItem({

        });
        pcwApp.logger.info(message, infoObj);
    },
    /**
     * 打印警告信息
     * @param {*} opt
     */
    warnLog(opt = {}) {
        const {ctx} = this;
        const request = ctx.request;
        let url = request.path;
        let routeUrl = request._matchedRoute;
        let params = request.params || {};
        let query = request.query || {};
        let param = Object.assign(params, query);
        let requestUrl = routeUrl || url;
        let error = new ApiError(opt)
        let logItem = new LogItem({
            api: requestUrl,
            apiParam: param,
            requestId: ctx.requestId,
            error
        });
        pcwApp.logger.warn(`[request ${requestUrl} warn]`, logItem);
    }
}
module.exports = ApiLog;
