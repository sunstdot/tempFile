"use strict";
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc:   中间层接口签名算法
 * @author: zhoujie@qiyi.com
 * @date:   2017-12-06
 */
const { Tool } = require('./util');
const apiCrypto = require('./crypto');
const authSign = {
	//参数签名算法
	paramSign(secretKey, timestamp, paramsObj) {
		//计算签名时， 需将参数按字典顺序排序
	    const sortObj = Tool.objKeySort(paramsObj);
	    //计算签名时，需按接口方约定的这种特殊字符串格式传参：`k1=v1|k2=v2|k3=v3|${secretKey}`
	    const str = Tool.objToSpecialStr(sortObj, '|');
	    const paramStr = str + secretKey;
	    //生成签名
	    const sign = apiCrypto.Md5(paramStr);
	    return sign;
	},
	//奇谱
	qipuBridgeSign() {
		const str = 'pcw_entity_hover:Gv2nnFNJ'
		return 'Basic ' + apiCrypto.Base64(str)
	}
}

module.exports = authSign;
