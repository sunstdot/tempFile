/**
 * @desc 日志格式定义
 * @author zhanghao
 * @version 1.0
 * @date 20170520
 */
const KEYS = [
    'api',               //pcw-api提供的对外接口地址
    'apiTime',           //pcw-api接口的响应时间
    'apiParam',          //pcw-api接口的请求参数
    'apiStatus',         //pcw-api接口的错误状态码
    'apiCode',           //pcw-api接口的code码
    'innerApi',          //pcw-api调用的业务方接口地址
    'innerApiTime',      //pcw-api调用的业务方接口的响应时间
    'innerApiParam',     //pcw-api调用的业务方接口的请求参数
    'requestId',         //一次pcw-api所有接口请求的唯一标识符
    'error',             //错误信息
    'referer'            //接口被哪个页面所调用
];
exports.LogItem = class {
    constructor(opt = {}) {
        for(let key of KEYS) {
            if(key === 'apiParam' || key === 'innerApiParam' || key === 'error') {
                this[key] = JSON.stringify(opt[key]) || "";
            }
            else if(key === 'apiTime' || key === 'apiStatus' || key === 'innerApiTime') {
                this[key] = opt[key] || 0;
            }
            else {
                this[key] = opt[key] || '';
            }
        }
    }
};
