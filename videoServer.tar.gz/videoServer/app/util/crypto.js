"use strict";
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc:   中间层加密模块
 * @author: sunshitao@qiyi.com
 * @date:   2017-11-09
 */
const crypto = require('crypto');
const apiCrypto = {
    //MD5加密，使用utf-8编码
    Md5(str){
        const md5 = crypto.createHash('md5');
        return md5.update(str, 'utf8').digest('hex');
    },
    Base64(str) {
        return Buffer.from(str).toString('base64');
    }
}

module.exports = apiCrypto
