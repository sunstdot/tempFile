'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: internal module provide node api package for app
 * 封装node api的系统方法
 * @author: sunshitao@qiyi.com
 * @date:   2018-02-26
 */
const {exec} = require('child_process');
async function execCmd(cmd) {
    return new Promise((resolve, reject) => {
        let data = {
            'type':'success'
        };
        exec(cmd, (error, stdout, stderr) => {
            if(error) {
                data.type = 'failed';
                data.data = error;
                resolve(data);
                return 
            }
            data.data = stdout;
            resolve(data);
        });
    }) 
}
class ProcessApi { 
    static async execPurgeCmd(ip, path) {
        let cmd = `curl -l -X PURGE -w %{http_code} http://${ip}${path}`;
        let result = await execCmd(cmd);
        result.ip = ip;
        result.path = path;
        let reg = new RegExp('200|404|502');
        result.data = result.data.match(reg)[0];
        
        return result;
    }
}

module.exports = {
    ProcessApi
}