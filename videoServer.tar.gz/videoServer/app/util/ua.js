/**
 * Copyright 2018 Qiyi Inc. All rights reserved.
 *
 * @desc: user-agent map
 * @author: zhoujie@qiyi.com
 * @date:   2018-03-12
 */

exports.ua = (userAgent) => {
    const _ua = userAgent.toLowerCase();
    // winphone手机ie浏览器的ua字符串内增加了like iphone, os x的字样，导致必须修改识别iphone的规则
    let trident = _ua.match(/trident/), iPad = !trident && _ua.match(/(ipad).*os\s([\d_]+)/),
    iPhone = !trident && !iPad && _ua.match(/(iphone\sos)\s([\d_]+)/),
    android = _ua.match(/(Android)\s+([\d.]+)/);

    if (/rv\:11/.test(_ua)) {
        return 'IE11';
    }
    if (/msie 10/.test(_ua)) {
        return 'IE10';
    }
    if (/msie 9/.test(_ua)) {
        return 'IE9';
    }
    if (/msie 8/.test(_ua)) {
        return 'IE8';
    }
    if (/msie 7/.test(_ua)) {
        return 'IE7';
    }
    if (/msie 6/.test(_ua)) {
        return 'IE6';
    }
    if (/opera/.test(_ua)) {
        return 'opera';
    }
    if (/chrome/.test(_ua)) {
        return 'chrome';
    }
    if (/360se/.test(_ua)) {
        return '360';
    }
    if (/firefox/.test(_ua)) {
        return 'firefox';
    }
    if (/safari/.test(_ua) && !(/chrome/.test(_ua))) {
        return 'safari'; 
    }
    if (/tencenttraveler/.test(_ua)) {
        return 'TT';
    }
    if (/ipad/.test(_ua) && !trident) {
        return 'iPad'; 
    }
    if (/pad/i.test(_ua)) {
        return 'pad';
    }
    if (/iPod/i.test(_ua) && !trident) {
        return 'iPod';
    }
    if (/iphone os [45]_/.test(_ua) && !trident) {
        return 'iPhone4';
    }
    if (/baidu/.test(_ua)) {
        return 'baidu'; //百度浏览器
    }
    if (/360/.test(_ua)) {
        return 'm360'; //360手机浏览器检测
    }
    if (/uc/.test(_ua)) {
        return 'muc'; //uc手机浏览器检测
    }
    if (/qq/.test(_ua)) {
        return 'mqq'; //qq浏览器检测
    }
    if (/lepad_hls/.test(_ua)) {
        return 'lePad'; //联想lePad检测
    }
    if (/windows/.test(_ua)) {
        return 'Win'; // window平台检测
    }
    if (/mac/.test(_ua)) {
        return 'Mac'; // mac平台检测
    }
    if (/iphone os/.test(_ua) && !trident) {
        return 'iPhone'; //i phone 的检测
    }
    if (/android/.test(_ua)) {
        return 'android'; //android 的检测
    }
    if (/windows phone/.test(_ua)) {
        return 'WP'; //windows phone的检测
    }
    if (/webkit/.test(_ua)) {
        return 'webkit';
    }
};
