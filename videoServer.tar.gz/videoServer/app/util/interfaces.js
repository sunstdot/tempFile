
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 * pcw-api idc机房列表如下
 * {
 *   "bjlt": "北京联通",
 *   "whdx": "武汉电信",
 *   "jyyd": "济阳移动",
 *   "bjdxt": "北京电信通",
 *   "bjyd": "北京移动",
 *   "bjdx": "北京电信"
 * }
 * 分机房接口配置，主要针对中间层的机房信息进行配置，接口配置优先级  同机房 > 同运营商 > 同地区 
 * 
 * @desc: interface module provide interface config
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 */
module.exports.videoQipuInterface = { 'url': 'http://qipu.qiyi.domain/video/getVideoBrief', 'timeout': 2000};   //奇谱新提供视频接口


//分机房接口配置,有机房域名的走机房域名，没有机房域名的走默认 'default'
const interfaceConfig = {
  videoScoreInterface: { 
    'default': 'http://score.bi.qiyi.domain/soya/get_user_movie_score', 
    'bjdx': 'http://bjdx.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'bjlt': 'http://bjlt.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'jyyd': 'http://jyyd.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'bjdxt': 'http://bjdxt6.score.video.qiyi.domain/beaver-api/external/get_user_movie_score',
    'timeout': 2000 
  }
};

//获取接口
module.exports.getInterface = (name) => {
  let inter = interfaceConfig[name];
  if(!idc || !inter[idc]) {
    url = inter.default;
  }else {
    url = inter[idc];
  }
  return {
    url,
    timeout: inter.timeout
  };
}

