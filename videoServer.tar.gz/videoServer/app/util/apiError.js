'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc:   中间层错误输出格式
 * @author: sunshitao@qiyi.com
 * @date:   2017-11-29
 * 
 */
const {IsType} = require('./util');
class ApiError {
    constructor(opt) {
        this.type = opt.type || 'pcw-api';
        this.message = opt.msg || 'An error occured';
        this.detail = opt.detail || '';
        this.data = opt.data || ''; //用户可以看到的错误信息
        this.apiError = true;  //标记通用Error跟apiError
        Error.captureStackTrace(this,ApiError);
        let stackStr = this.stack;
        if(IsType.isObject(this.stack)) {
            stackStr = JSON.stringify(this.stack);
        }
        this._stack = stackStr+'';
    }
}
module.exports = ApiError;
