'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: util module provide util method for app
 * underscore方法统一从这里引入，业务房智能调用util中导出的方法
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-11
 */

const _ = require('underscore')._;

function objectToString(o){
    return Object.prototype.toString.call(o);
}

class IsType {
    static is(clazz = 'Object') {
        return function (obj) {
            let type = '[object ' + clazz + ']';
            return (Object.prototype.toString.call(obj) === type);
        }
    }

    static isNum(s) {
        if (s != null && s != "") {
            return !isNaN(s);
        }
        return false;
    }

    static isObject(o) {
        return typeof o === 'object' && o !== null;
    }

    static isString(s) {
        return objectToString(s) === "[object String]"
    }


    static isArray(a) {
        if (Array.isArray) {
            return Array.isArray(a);
        }
        return objectToString(a) === "[object Array]"
    }

    static isFunction(f) {
        return typeof f === 'function';
    }

    static isBoolean(b) {
        return typeof b === 'boolean';
    }

    static isJson(body) {
        if (!body) return false;
        if ('string' == typeof body) return false;
        if ('function' == typeof body.pipe) return false;
        if (Buffer.isBuffer(body)) return false;
        return true;
    }

    static arrayFilterNull(arr) {
        if (arr && arr.length > 0) {
            return arr.filter(item => {
                return item !== '';
            });
        }
    }

    static isDate(date) { //eg:2018-06-01
        return (new Date(date).getDate() == date.substring(date.length - 2));
    }
}
/**
 *
 *
 * @class Tool
 */
class Tool {
    static generateRandomString() {
        const possible = 'ABCDEFGHIGKLMNOPQRSTUVWXYZabcdefghigklmnopqrstuvwxyz0123456789';
        const len = 62;
        let text = '';
        for (let i = 0; i < 3;i++) {
            text += possible.charAt(Math.floor(Math.random() * len));
        }
        return text;
    }
    /**
     * 数据过滤
     * @param data {object}
     * @param keys {array}
     * @returns {object}
     */
    static dataFilter(data,keys) {
        let newAlbum = {};
        if(keys && keys.length) {
            keys.forEach(key => {
                newAlbum[key] = data[key] !== undefined ? data[key] : data[key+""] !== undefined ? data[key+""] :"";
            });
            return newAlbum;
        }
        return data;
    }
    static isNull(value) {
        if (value === null || value === undefined) {
            return true;
        }
        return false;
    }
    /**
     * @param {*} obj  精简对象(不支持递归精简)
     * @param {*} args 支持传入数组['name','age'] 字符串'name','age'
     */
    static objectSimplification(obj,...args) {
        if (!obj || args.length == 0) {
            return;
        }
        let count = 0;
        let newObj = {};
        let params = args;
        if (args.length == 1 && IsType.isArray(args[0])){
            params = args[0];
        }
        let argsLength = params.length;
        while(count < argsLength) {
            if (!Tool.isNull(obj[params[count]])) {
                newObj[params[count]] = obj[params[count]];
            }
            count++ ;
        }
        return newObj;
    }
    /**
     * @param {*} obj  精简整个数组中每个对象(不支持递归精简)
     * @param {*} args 支持传入数组['name','age'] 字符串'name','age'
     */
    static objectArraySimplification(objArray,...args) {
        if (!IsType.isArray(objArray) || args.length == 0) {
            return;
        }
        let count = 0;
        let newArr = [];
        let argsLength = objArray.length;
        let params = args;
        if (args.length == 1 && IsType.isArray(args[0])){
            params = args[0];
        }
        while(count < argsLength) {
            let obj = Tool.objectSimplification(objArray[count],params);
            if (obj) {newArr.push(obj);}
            count++ ;
        }            
        return newArr.length ? newArr : objArray;
    }
    /**
     * 获取今天0点到某时刻时间戳
     * @param {String} date
     */
    static getTimestamp(date) {
        var curDate = String(date);        
        let reg = new RegExp(/\/|\-/,'ig');
        let today = new Date();
        today.setHours(0);
        today.setMinutes(0);
        today.setSeconds(0);
        today.setMilliseconds(0);

        let todayTime = today.getTime()/1000;
        if (reg.test(curDate)) {
            let tempDate = new Date(curDate);
            return todayTime - tempDate.getTime()/1000;
        }
        if (IsType.isNum(curDate)) {
            let length = curDate.length;
            if (length > 8) {
                return todayTime - curDate;
            } 
            if (length == 8) {
                let arr = [curDate.slice(0,4),curDate.slice(4,6),curDate.slice(6,8)];
                let tempDate = new Date(arr.join('-'));
                return todayTime - tempDate.getTime()/1000;
            }
        }
        return NaN;
    }
    /**
     * 数组拆分
     */
    static sliceArray(arr, num) {
        let tmpArr = [], start = 0, end = start + num;
        let len = arr.length;
        if(num >= len){
            return arr;
        }
        while(num < len && start < len){
            tmpArr.push(arr.slice(start,end));
            start+=num;
            end +=num;
        }
        return tmpArr;
    }
    /**
     * 将秒数转换成小时:分:秒的形式
     */
    static formatSeconds(s) {
        if (isNaN(s)) {
            return '00:00:00';
        }
        let h = Math.floor(s / 3600);
        let m = Math.floor(s % 3600 / 60);
        m = (m >= 10 ? m : ("0" + m));
        s = m >= 0 ? s % 3600 % 60 : s;
        s = (s >= 10 ? s : ("0" + s));
        return h > 0 ? ((h > 9 ? h : '0' + h) + ":" + m + ":" + s) : (m + ":" + s);
    }
    /*
    将20180101转换成2018-01-01
    */
    static formatFullDate(s) {
        if(s) {
            return s.slice(0, 4) + '-' + s.slice(4, 6) + '-' + s.slice(6, 8)
        }
        else {
            return "";
        }
    }
    /**
     * 将秒数转换成日期yyyy-mm-dd
     * @param s {Number}
     * @returns {String}
     */
    static formatSeconds2Date(s) {
        if(isNaN(s)) {
            return '';
        }
        const dateTime = new Date(s);
        let month = dateTime.getMonth() + 1;
        month = month > 9 ? month : ('0'+month);
        let dayTime = dateTime.getDate();
        dayTime = dayTime > 9 ? dayTime : ('0'+dayTime);
        return dateTime.getFullYear() + "-" + month + "-" + dayTime;
    }
    /**
     * 将对象按照属性名的字母顺序进行排序，返回排序好的字符串，如："k1=v1|k2=v2|k3=v3"
     * @param {*} obj  待排序的对象
     */
    static objKeySort(obj) {
        let newkey = Object.keys(obj).sort();
        let newObj = {};
        for (let i = 0; i < newkey.length; i++) {
            newObj[newkey[i]] = obj[newkey[i]];
        }
        return newObj;
    }
    /**
     * 将对象转换为特定的字符串输出，如："k1=v1|k2=v2|k3=v3"
     * @param {*} obj  待转换的对象
     * @param {*} splitStr  字符串分隔符，如："|"
     */
    static objToSpecialStr(obj, splitStr) {
        let objkeys = Object.keys(obj);
        let str = "";
        objkeys.forEach((key, i) => {
            str = `${str}${key}=${obj[key]}${splitStr}`;
        })
        return str;
    }
    /*
     * 将obj中的非空字段添加到params中
     * */
    static addUnemptyField(obj, params) {
        obj = obj || [];
        Object.keys(obj).forEach((item, idx)=>{
            if(obj[item]) {
                params[item] = obj[item];
            }
        });
    }
    /**
     * 按数组对象中的某个属性 根据升序降序进行排序
     * @param arr   对象数组
     * @param props 对象key值
     * @param order 排序方式
     * @returns {*}
     */
    static sortBy(arr, props, order) {
        [...arr].sort((a, b) => {
            let left = a[field], right = b[field];
            if(left === undefined || left === null) {
                return order == 'desc' ? 1 : -1;
            }
            if(right == undefined || right === null) {
                return order == 'desc' ? -1 : 1;
            }

            if(left > right) return order == 'desc' ? -1 : 1;
            if(left < right) return order == 'desc' ? 1 : -1;
        })
    }

    /**
     * 深度克隆对象
     * @param origin
     */
    static deepClone(origin) {
        let self = this;
        if(!origin) {
            return origin;
        } else if(IsType.isString(origin)) {
            return String.prototype.slice.call(origin);
        } else if(IsType.isNum(origin)) {
            return origin - 0;
        } else if(IsType.isBoolean(origin)) {
            return obj;
        } else if(IsType.isArray(origin)) {
            return [...origin];
        } else if(IsType.isObject(origin)) {
            return {
                __proto__: Object.getPrototypeOf(origin),
                ...origin
            };
        } else {
            return origin;
        }
    }
    /**
     * 从字符串中获得对应key的cookie值
     * @param {String} cookieStr  cookie字符串
     * @param {String} key cookie的key
     */
    static getCookieByKey(cookieStr, key) {
        const Cookies = {};
        if (typeof cookieStr === 'string') {
            cookieStr.split(';').forEach(item => {
                const parts = item.split('=');
                Cookies[parts[0].trim()] = (parts[1] || '').trim();
            });            
        }
        return Cookies[key];
    }
    /**
     * 检验登录参数
     * @param {String} cookieStr  cookie字符串
     */
    static checkLoginParams(cookieStr) {
        let msg = '';
        if (!this.getCookieByKey(cookieStr, 'P00001')) {
            return { 'type': 'params_error', 'msg': 'userinfoDetail', 'detail': `request lack of authcookie` };
        }
        if (!this.getCookieByKey(cookieStr, 'P00003')) {
            return { 'type': 'params_error', 'msg': 'userinfoDetail', 'detail': `request lack of uid` };
        }
        if (!this.getCookieByKey(cookieStr, 'QC005')) {
            return { 'type': 'params_error', 'msg': 'userinfoDetail', 'detail': `request lack of device_id` };
        }
        return false;
    }
    /**
     * 函数式编程 伪递归函数
     */
    static forRecursion([item, ...list], func) {
        // let newList = arguments[0];
        // newList.every(item => {
        //     return func(item);
        // })
        if(!item) return func(item);
        return func(item) || Tool.forRecursion(list, func);
    }
    /**
     * 返回对象属性名
    */
    static getObjKeysName(item) {
        return Object.keys(item)
    }
}

module.exports = {
    IsType,
    _,
    Tool
};
