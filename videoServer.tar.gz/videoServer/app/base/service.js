'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: Service base module  Service文件夹下继承的是这里实现的service类
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 */
const ApiLog = require('../util/apiLog');
const ApiError = require('../util/apiError');
const { IsType, Tool } = require('../util/util');

module.exports = app => {
    class Service extends app.Service{
        constructor(ctx){
            super(ctx);
        }

        /**===============================service层通用方法提供=============================*/
        // 统一的dao 数据处理
        baseDaoDataCheck(data, level) {
            const {ctx} = this;
            let request = ctx.request;
            let innerUrl = ctx.innerUrl;
            let url = request.path;
            let param = Object.assign(request.params || {}, request.query || {});
            if(data.type !== 'success') {
                if(level === 'warn') {
                    ApiLog.warnLog.apply(this, [{'type': data.type,'msg': `${url}`,'detail': `request ${innerUrl} interface failed:` + JSON.stringify(param)}]);
                } else if(level === 'error') {
                    throw new ApiError({
                        type: data.type, 
                        msg: `${url} request ${innerUrl} interface failed with params: ${param}`,
                        detail: `${JSON.stringify(data.data, null, 2)}`
                    });
                }
            }
            return data.data || {};
        }
        /**
         * 基于某种条件对数据进行分类, 可复写该方法
         * @param source {Array} 原始数据
         * @param condition {object} 分类条件 key值为分类的类名， value为分类后的数据
         * example:
         *   condition: {
         *       'video': {
         *           qipu_id: '00$',
         *           videoType: '1',
         *           test: function(item) {
         *              //自定义检查方法
         *           }
         *       },
         *       'album': {
         *          qipu_id: '01$'
         *          videoType: '2',
         *          test: function(item) {
         *              //自定义检查
         *          }
         *       }
         *   }
         * @param fields {key} 分类后保留字段
         * @return {Array}  分类后数据
         */
        dataClassify(source, condition, fields) {
            let destination = {};
            if(IsType.isArray(source)) {
                source.map(item => {
                    for(let key in condition) {
                        if(key && condition.hasOwnProperty(key)) {
                            let conditionValue = condition[key];
                            let isOk = false;
                            destination[key] = destination[key] || [];
                            for(let ckey in conditionValue) {
                                let cvalue = conditionValue[ckey];
                                if(IsType.isFunction(cvalue)) {
                                    isOk = cvalue.apply(item);
                                }else {
                                    isOk = (new RegExp(cvalue)).test(item[ckey]);
                                }
                            }
                            if(isOk) {
                                item = fields ? item : (fields.length === 1 ? item[fields[0]] : Tool.dataFilter(item, fields));
                                destination[key].push(item);
                            }
                        }
                    }
                });
                return destination;
            }else {
                return 'cannot classify';
            }
        }

        /**
         * 数据合并,
         * @param sourceData1
         * @param sourceData2
         * @param keys1 第一源数据合并保留keys值
         * @param keys2 第二源数据合并保留keys值
         */
        dataMerge(sourceData1, sourceData2, keys1, keys2) {

        }


        /**
         * 并行接口类请求,dao可能是一个可能是多个一一对应
         * param data {Array} 请求参数数组
         * param dao {Function} dao接口请求函数
         * return {Array} 接口请求数据结果
         */
        async parallelRequest(data, dao) {
            let tempList = data.map(function(item) {
                return dao(item);
            });
            let results = await Promise.all(tempList);
            return results;
        }

        /**
         * 串行接口类请求
         * param data {Array} 请求参数数组
         * param dao {Function} dao接口请求函数
         * return {Array} 接口请求数据结果
         */
        async sequenceRequest(data, dao) {
            let tempList = [];
            for(let item of data) {
                let tempItem = await dao(item);
                tempList.push(tempItem);
            }
            return tempList;
        }
    }

    return Service;
}