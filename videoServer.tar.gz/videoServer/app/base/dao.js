'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: dao base module dao目录下继承的是这里实现的Dao类,封装http请求方法
 * @author: sunshitao@qiyi.com
 * @date:   2017-09-14
 */

const dns = require('dns');
const { URL } = require('url');

const request = require('request');
const ApiError = require('../util/apiError');
const { LogItem } = require('../util/logItem');
const env = process.env.NODE_ENV;
const http = require('http');
const pool = new http.Agent();
pool.maxSockets = 1500;
pool.keepAliveMsecs = 3000;
module.exports = app => {
    class Dao extends app.Dao {
        constructor(ctx) {
            super(ctx);
        }
        request(options, callback) {
            options.headers = options.headers || {};
            return request(options,callback);
        }

        async requestRetry(options) {
            let predicate = function(error) {
                return error && error.toString() && error.toString().indexOf('ESOCKETTIMEDOUT') > -1;
            };
            return retry(function() {
                return request.getAsync(options);

            }, {
                max_tries: 3,
                interval:200,
                predicate
            });
        }

        //dns查询闭包
        lookup(url, requestId) {
            let domainName = new URL(url).host;
            return function() {
                dns.lookup(domainName, (err, address, family) => {
                    app.logger.warn(`[request ${domainName} ${address} error, requestId: ${requestId}]`, {});
                });
            }
        }

       /**
       * 不推荐使用，只有接口请求中不能带requestId时才可以使用
       * 封装httpGet请求，包装接口请求id，打印出错接口日志,打印接口请求时长
       * @param url {string} 接口日志打印 api  (restful api 作区分)
       * @param qs {object}
       * @param timeout {number}
       * @param supplement {object} 接口补充参数，没有传空对象
       * @param headers {object} 接口请求header，没有传空对象
       * @return {any}
       */
       async requestGet(url, qs = {}, timeout = 3000, supplement = {}, headers = {}) {
            if (!url) {
                return;
            }

            const startTime = process.hrtime();
            let requestId = this.ctx.requestId;   //一次接口请求的唯一id
            let innerUrl = this.ctx.innerUrl;   //获取业务方接口请求路由连接
            let _routeUrl = this.ctx._matchedRoute; // 获取业务方接口的路由

            return new Promise((resolve, reject) => {
                let options = Object.assign({
                    url,
                    qs,
                    headers,
                    timeout
//                    pool,
//                    forever: true,
                }, supplement);
                //测试环境下走代理模式
                //奇谱接口走代理环境有问题
                // if(env && (env === 'test' || env === 'development') && url.indexOf("qipu.qiyi.domain")<0) {
                    
                //      let proxy = this.app.config.proxy.passby;
                //      headers = Object.assign(headers,this.ctx.headers); //dev环境下透传header
                //      options = Object.assign(options, {
                //          proxy,
                //          headers
                //      });
                // }

                //打印dns解析结果
                // this.lookup(url, requestId)();                
                this.request(options, function (err, httpResponse, body) {
                    let data = {
                        type: 'success'
                    };

                    //接口报错或者接口状态码非200 均为接口请求错误
                    if (err || httpResponse.statusCode !== 200) {
                        let remoteIp = this.remoteIp;

                        data.type = 'request_failed';
                        let msgMore;
                        let paramStr = JSON.stringify(qs);
                        if (err && (err.code == 'ESOCKETTIMEDOUT' || err.code == 'ETIMEDOUT')) {
                            data.type = 'timeout_error';
                            let detail = JSON.stringify({'message': err.message, 'stack': err.stack + ''});
                            if(err.code === 'ETIMEDOUT') {
                                msgMore = `connect ${remoteIp} timeout: ${detail} with param: ${paramStr}`;                 //连接超时
                            }else {
                                msgMore = `${remoteIp} response timeout: ${detail} with param: ${paramStr}`;                //响应超时
                            }
                        } else if(httpResponse && httpResponse.statusCode !== 200) {
                            msgMore = `request interface ${url} at ${remoteIp} with statuscode: ${httpResponse.statusCode} and param: ${paramStr}`;
                        } else {                            
                            msgMore = `request interface ${url} at ${remoteIp} error: ${httpResponse} with param: ${paramStr}`;
                        }
                        data.data = msgMore;
                        let errorString = JSON.stringify(err);
                        let error = new ApiError({'type': data.type, 'msg': msgMore, 'detail': body,'error':errorString});
                        let errObj = new LogItem({
                            innerApi: innerUrl,
                            innerApiParam: qs,
                            requestId,
                            error
                        });
                        app.logger.error(`[request ${url} error]`, errObj);
                        resolve(data);
                        return;
                    }
                    //打印接口日志信息
                    // const totalTime = (new Date()).getTime() - startTime;
                    // let infoObj = new LogItem({
                    //     api: _routeUrl,
                    //     innerApi: innerUrl,
                    //     innerApiTime: totalTime,
                    //     innerApiParam: qs,
                    //     requestId
                    // });
                    // app.logger.info(`[request ${url} info]`, infoObj);

                    try {
                        data.data = JSON.parse(body);
                    } catch (e) {
                        //todo 打印一个警告即可
                        try{
                            data.data = eval('(' + body + ')');
                        } catch(e){
                            data.data = {};
                        }

                    }
                    resolve(data);
                });
            });
        }
       /**
        * 封装httpGet restful 请求，包装接口请求id
        * @param url {string} 接口日志打印 api  (restful api 作区分)
        * @param id {string}
        * @param timeout {number}
        * @param supplement = {
        *     qsStringifyOptions: {
        *         encodeURIComponent: url => url
        *     },
        *     useQuerystring: true
        *     ....
        * } {object} 接口补充参数，没有传空对象,使用方式参见：https://github.com/request/request#requestoptions-callback
        * @param headers = {
        *     Cookie: cookie {object}, cookie是对象类型的
        *     content-encoding: xxx,
        *     content-type: xxx
        *     ....
        * }
        * @return {any}
        */
        async requestGetRestful(url, id, timeout, supplement = {}, headers = {}, qs = {}) {
            const {ctx} = this;
            ctx.innerUrl = url;
            qs.requestId = ctx.requestId;
            return await this.requestGet(url + '/' + id, qs, timeout, supplement, headers);
        }

       /**
        * 推荐使用！！
        * 封装httpGet请求，包装接口请求id，打印出错接口日志,打印接口请求时长,在接口中加入requestId用来跟踪记录
        * @param url {string} 接口日志打印 api  (restful api 作区分)
        * @param qs {object}
        * @param timeout {number}
        * @param supplement = {
        *     qsStringifyOptions: {
        *         encodeURIComponent: url => url
        *     },
        *     useQuerystring: true
        *     ....
        * } {object} 接口补充参数，没有传空对象,使用方式参见：https://github.com/request/request#requestoptions-callback
        *
        * @param headers = {
        *     Cookie: cookie {object}, cookie是对象类型的
        *     content-encoding: xxx,
        *     content-type: xxx
        *     ....
        * }
        * @return {any}
        */
        async requestGetWithId(url, qs = {}, timeout, supplement = {}, headers = {}) {
            const {ctx} = this;
            ctx.innerUrl = url;
            qs.requestId = ctx.requestId;
            return await this.requestGet(url, qs, timeout, supplement, headers);
        }

        /**
         * 接口不支持传requestId参数时推荐使用！！！
         * 封装httpGet请求，包装接口请求id，
         * @param url {string} 接口日志打印 api  (restful api 作区分)
         * @param qs {object}
         * @param timeout {number}
         * @param supplement = {
         *     qsStringifyOptions: {
         *         encodeURIComponent: url => url
         *     },
         *     useQuerystring: true
         *     ....
         * } {object} 接口补充参数，没有传空对象,使用方式参见：https://github.com/request/request#requestoptions-callback
         *
         * @param headers = {
         *     Cookie: cookie {object}, cookie是对象类型的
         *     content-encoding: xxx,
         *     content-type: xxx
         *     ....
         * }
         * @return {any}
         */
        async requestGetHeaderId(url, qs = {}, timeout, supplement = {}, headers = {}) {
            const {ctx} = this;
            headers.requestId = ctx.requestId;
            ctx.innerUrl = url;
            return await this.requestGet(url, qs, timeout, supplement, headers);
        }

//=============================================request post方法===================================================
        //
        /**
         * http post请求方法， 内部使用form进行post提交
         * @param url {String}  post投递地址
         * @param param {Object} post投递内容
         * @return {any} 返回值
         */
        async requestPost(url, param) {

            let startTime = (new Date()).getTime();
            let requestId = this.ctx.requestId;         //一次接口请求的唯一Id
            // let _routeUrl = this.ctx._matchedRoute; // 获取业务方接口的路由
            let innerUrl = this.ctx.innerUrl;   //获取业务方接口请求路由连接

            return new Promise((resolve, reject) => {
                request.post({url, form: param}, function(err, httpResponse, body) {
                    let remoteIp = this.remoteIp;
                    let data = {
                        type: 'success'
                    };

                    if(err || httpResponse.statusCode !== 200) {
                        data.type = 'request_failed';
                        let msgMore = '';
                        if (err && (err.code == 'ESOCKETTIMEDOUT' || err.code == 'ETIMEDOUT')) {
                            data.type = 'timeout_error';
                            let detail = JSON.stringify({'message': err.message, 'stack': err.stack + ''});
                            if(err.code === 'ETIMEDOUT') {
                                msgMore = `connect ${remoteIp} timeout: ${detail}`;                 //连接超时
                            }else {
                                msgMore = `${remoteIp} response timeout: ${detail}`;                //响应超时
                            }
                        } else {
                            msgMore = `POST interface ${url} at ${remoteIp} with statuscode: ${httpResponse.statusCode}`;
                        }
                        data.data = msgMore;
                        let error = new ApiError({'type': data.type, 'msg': 'requestPost' + msgMore, 'detail': body});
                        let errObj = new LogItem({
                            innerApi: url,
                            innerApiParam: param,
                            requestId,
                            error
                        });
                        app.logger.error(`[request post ${url} error]`, errObj);
                        resolve(data);
                        return;
                    }
                    //打印接口日志信息 (由于ES集群硬盘容量不够，故取消掉dao层日志打印)
                    // const totalTime = (new Date()).getTime() - startTime;

                    // let infoObj = new LogItem({
                    //     api: _routeUrl,
                    //     innerApi: innerUrl,
                    //     innerApiTime: totalTime,
                    //     innerApiParam: param,
                    //     requestId
                    // });
                    // app.logger.info(`[request POST ${url} info]`, infoObj);

                    try {
                        data.data = JSON.parse(body);
                    } catch (e) {
                        //todo 打印一个警告即可
                        data.data = eval('(' + data + ')');
                    }
                    resolve(data);
                });
            });

        }
    }
    return Dao;
}
