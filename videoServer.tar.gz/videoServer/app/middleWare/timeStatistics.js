'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: middleware module for interface request statistics 接口访问长统计
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-28
 * @version 1.0.1 添加LogItem日志格式类 by zhanghao on 20170520
 */
const {Tool} = require('../util/util');
const {LogItem} = require('../util/logItem');
module.exports = () => {
    return async (ctx,next) => {
        let url = ctx._matchedRoute;
        let startTime = (new Date()).getTime();
        ctx.requestId = startTime + Tool.generateRandomString();
      
        await next();      
             
        let totalTime = (new Date()).getTime() - startTime;
        let params = ctx.params || {};
        let query = ctx.query || {};
        let param = Object.assign(params, query);
        let status = ctx.response.status;       
        let logItem = new LogItem({
            api: url,
            apiTime: totalTime,
            apiParam: param,
            apiStatus: status,
            apiCode: ctx.body.code,
            requestId: ctx.requestId,
            referer: ctx.request.header.referer || query.referer
        });        
        pcwApp.logger.info(`[request ${url} time]`,logItem);
         
    };
};