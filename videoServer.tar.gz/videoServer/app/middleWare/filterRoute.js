'use strict';
/**
 * Copyright 2018 Qiyi Inc. All rights reserved.
 *
 * @desc: router handler middleware 过滤接口随机变量中间件
 * @author: sunshitao@qiyi.com
 * @date:   2018-07-02
 */
const routeFilter = require('../../config/routeFilter');
const {httpCode, httpStatus} = require('../util/httpCode');

module.exports = () => {
  return async (ctx, next) => {
    let searchUrl = ctx.search;
    let query = Object.assign({},ctx.query);
    let path = ctx.path;
    //待过滤关键字
    let filterList = routeFilter.common;
    let isRedirect = false;
    filterList.forEach(key => {
      if(query[key]) {
        Reflect.deleteProperty(query, key);
        isRedirect = true;
      } 
    });
    //是否需要重定向
    if(isRedirect) {
      let data = await ctx.dao.video.requestGet(`http://127.0.0.1:18080${path}`, query);
      //如果获取数据成功
      if(data.type === 'success' && data.data.code === 'A00000') {
        ctx.status = 200;
        ctx.body = data.data;
      }else {
        await next();
      }
    }else {
      await next();
    }
  };
}