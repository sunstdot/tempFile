﻿'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: middleware module solve jsonp request
 * @author: sunshitao@qiyi.com
 * @date:   2017-08-11
 */

module.exports = app => {
    return async (ctx,next) => {
        let callback = ctx.query ? ctx.query.callback : undefined;
        await next();

        if(ctx.body == null) return;

        if (callback) {
            let limit = 512;        //jsonp中通过script发送请求，url长度有限制，不能发送超过2048字节的请求
            if(callback.length > limit) {
                callback = callback.substring(0, limit);
            }
            //callback 只允许"[","]","a-zA-Z0123456789_", "$" and "." characters
            let cb = callback.replace(/[^\[\]\w$.]/g, '');
            ctx.body = 'try{ '+ cb +'('+JSON.stringify(ctx.body)+');}catch(e){}';
        }
    }
}
