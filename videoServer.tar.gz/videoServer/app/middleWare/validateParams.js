/*
  @desc: 参数验证中间件
  @author: zhaorui
  @date: 2017.11.15
*/

'use strict';

const schema = require('../../config/schema');
const forEach = require('lodash/forEach');
const ApiError = require('../util/apiError');

/**
 * 验证请求参数，并返回一个包含了所有错误参数信息的对象
 * @param  {Object} params   ctx.params和ctx.query的合并
 * @param  {Object} restrict 在schema中对应路由的配置信息
 * @param  {Object} ctx      请求上下文
 * @return {Object}          所有的错误信息
 *    key值是对应的参数名
 *    value值是对象，格式如下
 *      {
 *        validator: schema中定义的对应的参数的验证方式
 *        value: 接口中参数对应的值
 *      }     
 */
function checkErrors (params, restrict, ctx) {
  let errors = false;

  function addError (key, value, validator) {
    errors = errors || {};
    errors[key] = {
      validator,
      value
    };
  }

  forEach(restrict, (validator, key) => {
    const paramsValue = params[key];

    switch (typeof validator) {
      case 'function':
        if (!validator(paramsValue, ctx)) {
          addError(key, paramsValue, validator);
        }
        break;
      case 'string':
        if (!RegExp(validator).test(paramsValue)) {
          addError(key, paramsValue, validator);
        }
        break;
      default:
        throw new ApiError({
          type: 'validateParams',
          msg: 'middleware - validateParams',
          detail: `验证${key}的schema格式错误，必须为正则字符串或者函数`,
          data: `验证${key}的schema格式错误，必须为正则字符串或者函数`
        });
    }
  });

  return errors || false;
}

function throwErrors (errors) {
  let errorMsg = '';

  forEach(errors, (errorInfo, param) => {
    errorMsg += `${param}参数的值为'${errorInfo.value}'，不满足条件'${errorInfo.validator}';`;
  });

  throw new ApiError({
    type: 'arg_error',
    msg: 'middleware - validateParams',
    detail: errorMsg,
    data: errorMsg
  });
}

module.exports = () => {
  return async (ctx, next) => {
    const key = `${ctx.method} ${ctx._matchedRoute}`;
    const restrict = schema[key];
    let params = ctx.params || {};
    let query = ctx.query || {};

    const errors = checkErrors(Object.assign(params, query), restrict, ctx);

    if (errors) {
      throwErrors(errors);
    }
    await next();
  }
}