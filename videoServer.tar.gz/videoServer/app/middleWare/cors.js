/**
 * @fileOverview :支持cors
 * @author zhaorui
 * @date 2018.03.23
 */

'use strict';

module.exports = () => {
    return async (ctx, next) => {
        const env = process.env.NODE_ENV;
        const envEnableCors = ['test', 'development'];
        const whitelist = [
            'http://main.iqiyi.com:9090',
            'http://www.iqiyi.com',
            'https://www.iqiyi.com'
        ];
        const requestOrigin = ctx.accept.headers.origin;
        console.log('>>>>>>>>>'+requestOrigin);
        // if (env && envEnableCors.indexOf(env) >= 0 && whitelist.includes(requestOrigin)) {
            ctx.set({
                'Access-Control-Allow-Origin': requestOrigin,
                'Access-Control-Allow-Credentials': true
            });
        // }

        await next();
    }
}