'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: middleware module for ip control 限制接口访问ip
 * @author: sunshitao@qiyi.com
 * @date:   2017-11-21
 */
const ApiError = require('../util/apiError');
const clientIp = require('../util/clientIp')
const ipList = ['10.', '192.', '127.0.0.1'];

module.exports = () => {
    return async (ctx,next) => {
        let req = ctx.request.req;
        let user_ip = clientIp.getClientIp(req);
        global.pcwApp.logger.info(user_ip+'==============fromipcontrol');
        let access = false;
        for (let i = 0; i < ipList.length; i++) {
            let item = ipList[i];
            if (user_ip.indexOf(item) === 0) {
                access = true;
                break;
            }
        }
        if (access) {
            await next();
        } else {
            throw new ApiError({ type: 'access_deny', 'msg': 'ipcontrol', 'detail': `ip ${clientIp} illegal` });
        }
    };
};