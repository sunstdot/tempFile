'use strict';
/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: controller index module provide heart_check api interface
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-19
 */
const {httpCode} = require('../util/httpCode');
module.exports = app => {
    class IndexController extends app.Controller {
        * welcome() {
            const {ctx} = this;
            let app = global.pcwApp;
            ctx.body = httpCode('success',{'msg':'welcome to use pcw-api service', 'version': app.version, 'publish': app.publish });
        }
    }
    return IndexController;
}
