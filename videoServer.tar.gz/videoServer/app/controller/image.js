const {httpCode} = require('../util/httpCode');


module.exports = app => {
  class ImageController extends app.Controller {
    async upload() {
      console.log('==========upload');
      let {ctx,service} = this;
      let method = ctx.request.method;
      let data;
      if(method == 'OPTIONS') {
        data = {data:'success'}; 
      }else if(method == 'POST') {
        data = await service.image.upload();
      }
      ctx.status = 200;
      ctx.body = httpCode('success', data);
    }
  }
  return ImageController;
}