const formidable = require('koa-formidable'); // 图片处理
const fs = require('fs');
const path = require('path');


let mkdirs = (dirname, callback)=> {
  fs.exists(dirname, function(exists) {
      if (exists) {
          callback();
      } else {
          mkdirs(path.dirname(dirname), function() {
              fs.mkdir(dirname, callback);
          });
      }
  });
};
module.exports = app => {
  class ImageService extends app.Service {
    constructor(ctx) {
      super(ctx);
    }
    async upload() {
      const {ctx} = this;
      let form = formidable.parse(ctx.request);
      function formImage() {
        return new Promise((resolve, reject) => {
          form((opt, {fields, files})=> {
            let filename = files.file.name;
            let projectName = fields.projectName; //前端加上时间戳防止名字重复
            console.log(files.file.path);
            let uploadDir = `public/${projectName}/`;
            let avatarName = Date.now() + '_' + filename;
            mkdirs(uploadDir, function() {
              fs.renameSync(files.file.path, uploadDir + avatarName); //重命名
              resolve({url:'http://api.xuedianyun.com:50501/' + uploadDir + avatarName, imgIndex:fields.imgIndex})
              // http://localhost:6001/public/upload/1513523744257_WX20171205-150757.png
            })
          })
        })
      }
      let data = await formImage();
      return data;
    }
  }
  return ImageService;
}