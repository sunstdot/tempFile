/**
 * mock接口数据
 * Created by sunshitao on 2017/4/19.
 */
module.exports = {
    viewPointData : [
        {
            videoId:'641851900',
            imgUrl:'http://pic9.qiyipic.com/image/20170408/59/96/v_112087380_m_601_m2_160_90.jpg',
            timeline:'2735'
        },
        {
            videoId:'642449300',
            imgUrl:'http://pic9.qiyipic.com/image/20170408/59/96/v_112087380_m_601_m2_160_90.jpg',
            timeline:'2735'
        },
        {
            videoId:'643066400',
            imgUrl:'http://pic9.qiyipic.com/image/20170408/59/96/v_112087380_m_601_m2_160_90.jpg',
            timeline:'2735'
        },
        {
            videoId:'643687100',
            imgUrl:'http://pic9.qiyipic.com/image/20170408/59/96/v_112087380_m_601_m2_160_90.jpg',
            timeline:'2735'
        }
    ]
};
