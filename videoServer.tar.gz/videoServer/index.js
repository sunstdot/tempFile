/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 * test
 * @desc: index module start server
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 */
'use strict';

process.env.UV_THREADPOOL_SIZE = 24;
const App = require('./app/app');
let options = {
    'rootDir':__dirname,
    'port': 50501
};

(function(root) {
     process.argv.forEach(function (val,index,file) {
         let port = process.argv[3];         
         options.port = port;
         global.idc = "bjlt";
         switch (val) {
             case '--start':
                 const app = new App(options);                 
                 global.pcwApp = app;  //定义值为app的全局变量
                 app.logger.info('start app on port %',{'port':port});
                 break;
             default:
                 break;
         }
     });
 })(this);
