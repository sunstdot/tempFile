/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: 明星信息接口测试用例
 * @author: sunshitao@qiyi.com
 * @date:   2018-03-07
 */
const requestAsync = require('../../testlib/request');
const assert = require('assert');
const starinfoUrl = 'http://pcw-api.iqiyi.com/star/star/basicstarinfo/';
describe('test/star/star.basicstarinfo.test.js', () => {
    it('should GET /star/star/basicstarinfo/ success', (done) => {
        const param = {
            starId: "203445205"
        };
        let code = 'A00000';
        (async function () {
            try {
                let infoData = await requestAsync(starinfoUrl, param, 2000);
                assert.equal(infoData.status, 200);
                // console.log(infoData.data.code+"---------------------------")
                assert.equal(infoData.data.code, code);
                done();
            } catch (err) {
                done(err);
            }
        })();

    });
    it('should GET /star/star/basicstarinfo/ not_found', (done) => {
        const param2 = {
            starId: "2034452051"
        };
        (async function () {
            try {
                let infoData = await requestAsync(starinfoUrl, param2, 2000);
                assert.equal(infoData.status, 200);
                assert.equal(infoData.data.code, 'A00002');
                done();
            } catch (err) {
                done(err);
            }
        })();
    });
})
