/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: hotfeed接口测试用例
 * @author: sunshitao@qiyi.com
 * @date:   2018-03-07
 */
const requestAsync = require('../../testlib/request');
const assert = require('assert');
const hotFeedUrl = 'http://pcw-api.iqiyi.com/passport/user/userinfodetail';
describe('test/passport/record.recommend.test.js', () => {
    it('should GET /passport/user/userinfodetail success', (done) => {
        const param = {
        };
        let code = 'A00000';
        (async function () {
            try {
                let infoData = await requestAsync(hotFeedUrl, param, 2000);
                assert.equal(infoData.status, 200);
                // console.log(infoData.data.code+"---------------------------")
                assert.equal(infoData.data.code, code);
                done();
            } catch (err) {
                done(err);
            }
        })();
    });
})
