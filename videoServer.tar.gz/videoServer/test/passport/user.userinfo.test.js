/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: passport用户信息接口测试用例
 * @author: sunshitao@qiyi.com
 * @date:   2018-03-07
 */
const requestAsync = require('../../testlib/request');
const assert = require('assert');
const userinfoUrl = 'http://pcw-api.iqiyi.com/passport/user/userinfo';
describe('test/passport/user.userinfo.test.js', () => {
    it('should GET /passport/user/userinfo success', (done) => {
        const param = {
            uid: "1204783448"
        };
        let code = 'A00000';
        (async function () {
            try {
                let infoData = await requestAsync(userinfoUrl, param, 2000);
                assert.equal(infoData.status, 200);
                // console.log(infoData.data.code+"---------------------------")
                assert.equal(infoData.data.code, code);
                done();
            } catch (err) {
                done(err);
            }
        })();

    });

    it('should GET /passport/user/userinfo arg_error', (done) => {
        const param3 = {
            uid: "1204783448s"
        };
        (async function () {
            try {
                let infoData = await requestAsync(userinfoUrl,param3, 2000);
                assert.equal(infoData.status, 200);
                assert.equal(infoData.data.code, 'A00001');
                done();
            } catch (err) {
                done(err);
            }
        })();
    });

})
