/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: businesstype 用户业务列表接口测试用例 参数从cooke中获取，待验证
 * @author: sunshitao@qiyi.com
 * @date:   2018-03-07
 */
// const requestAsync = require('../../testlib/request');
// const assert = require('assert');
// const businesstypesUrl = 'http://pcw-api.iqiyi.com/passport/user/businesstypes';
// describe('test/passport/businesstypes.test.js', () => {
//     it('should GET /passport/user/businesstypes success', (done) => {
//         const param = {
//             albumid: "207680801"
//         };
//         let code = 'A00000';
//         (async function () {
//             try {
//                 let infoData = await requestAsync(businesstypesUrl, param, 2000);
//                 assert.equal(infoData.status, 200);
//                 // console.log(infoData.data.code+"---------------------------")
//                 assert.equal(infoData.data.code, code);
//                 done();
//             } catch (err) {
//                 done(err);
//             }
//         })();

//     });

// })
