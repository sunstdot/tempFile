/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: 直播视频信息接口测试用例
 * @author: sunshitao@qiyi.com
 * @date:   2018-03-07
 */
const requestAsync = require('../../testlib/request');
const assert = require('assert');
const videoUrl = 'http://pcw-api.iqiyi.com/live/video/videoinfo';
describe('test/live/video.videoinfo.test.js', () => {
    it('should GET /live/video/videoinfo success', (done) => {
        const param = {
            page: "3",
            size: "2",
            type:'order_hot'
        };
       
        let code = 'A00000';
        (async function() {
            try {
              let infoData = await requestAsync(videoUrl, param, 2000);
              assert.equal(infoData.status, 200);
              // console.log(infoData.data.code+"---------------------------")
              assert.equal(infoData.data.code, code);
              done();
            }catch(err) {
              done(err);
            }
        })();

    });

    it('should GET /live/video/videoinfo arg_error', (done) => {
        const param = {
            page: "3",
            size: "2s"
        };
        (async function() {
            try {
              let infoData = await requestAsync(videoUrl, param, 2000);
              assert.equal(infoData.status, 200);
              assert.equal(infoData.data.code, 'A00001');
              done();
            }catch(err) {
              done(err);
            }
        })();
    });

})
