/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: indextrend接口测试用例
 * @author: sunshitao@qiyi.com
 * @date:   2018-03-07
 */
const requestAsync = require('../../testlib/request');
const assert = require('assert');
const viewPointUrl = 'http://pcw-api.iqiyi.com/indextrend/video/viewpoint';
const scenePointUrl = 'http://pcw-api.iqiyi.com/indextrend/video/scene';
describe('test/indexTrend/video.viewpoint.test.js', () => {
    it('should GET /indexTrend/video/viewpoint success', (done) => {
        const param = {
            albumId: "206206701",
            name: "美食"
        };
        let result = {
            name: "人民的名义第34集",
            url: "http://www.iqiyi.com/v_19rrax5864.html",
            videoId: 655439600,
            timestamp: 1143,
            imgUrl:"http://isearch.qiyipic.com/videoout/20170429/05/83/videoout_590414ed74d5795978940583_220x124.jpg"
        };
        let code = 'A00000';
        (async function() {
            try {
              let infoData = await requestAsync(viewPointUrl, param, 2000);
              assert.equal(infoData.status, 200);
              // console.log(infoData.data.code+"---------------------------")
              assert.equal(infoData.data.code, code);
              assert.deepEqual(infoData.data.data[0][0], result);
              done();
            }catch(err) {
              done(err);
            }
        })();

    });
    it('should GET /indexTrend/video/viewpoint not_found', (done) => {
        const param2 = {
          albumId: "206206701",
          name: "美"
        };
        (async function() {
            try {
              let infoData = await requestAsync(viewPointUrl, param2, 2000);
              assert.equal(infoData.status, 200);
              assert.equal(infoData.data.code, 'A00002');
              done();
            }catch(err) {
              done(err);
            }
        })();
    });

    it('should GET /indexTrend/video/viewpoint arg_error', (done) => {
        const param3 = {
          albumId: "206206701",
          name: ""
        };
        (async function() {
            try {
              let infoData = await requestAsync(viewPointUrl, param3, 2000);
              assert.equal(infoData.status, 200);
              assert.equal(infoData.data.code, 'A00001');
              done();
            }catch(err) {
              done(err);
            }
        })();
    });

})
