/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: 异步接口封装
 * @author: sunshitao@qiyi.com
 * @date:   2017-07-21
 */
const request = require('request');

//封装异步接口请求
function requestAsync(url,qs,timeout) {
    timeout = timeout || 3000;
    return new Promise((resolve,reject) => {
        request({
            url,
            qs,
            timeout,
            headers: {}
        }, (error, response, body) => {
            // if(response.statusCode == 200) {
            //     resolve(body);
            // }else {
            //     reject(response.statusCode);
            // }
            let data;
            try {
               data = JSON.parse(body);
            }catch(err) {
               data = eval('('+body+')');
            }
            resolve({status: response.statusCode, data});
        });
    });
}


module.exports = requestAsync;
