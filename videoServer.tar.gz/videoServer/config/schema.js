/*
  @desc: 请求参数校验配置文件。
    每个参数的值可以是一个函数，也可以是一个正则字符串。
    函数有两个参数，第一个参数是对应的请求参数的值；第二个参数是ctx上下文。

    不需要验证的路由可以不写；
    不需要验证的params可以不写;

  @author: zhaorui
  @date: 2017.11.15
*/

'use strict';

const number = '^[0-9]+$';
const numberOrBlank = '^[0-9]*$|^undefined$';
const string = '[0-9][a-z]+|';
const blank = 'undefined|^\\s*$'; // 可以为空

module.exports = {
  // http://wiki.qiyi.domain/pages/viewpage.action?pageId=155743484
  'GET /live/video/videoinfo': {
    page: numberOrBlank,
    size: numberOrBlank,
    type: `order_hot|order_pre|order_all|${blank}`,
    except_sub_type: '',
    except_type: '',
    fields: '',
    provider_type: `UGC_TYPE|PPC_TYPE|${blank}`,
    live_episode_type: `LIVE_EPISODE_TYPE_SHOP|LIVE_EPISODE_TYPE_AIPINDAO|${blank}`,
    recommend_rate: '',
    category: '',
    play_status: `LIVE_TYPE|REPLAY_TYPE|REQUEST_TYPE|WAITING|PLAY_STATUS_NULL|${blank}`

  },

  'GET /subscribe/subscription/tonglan-updates': {
    terminalId: number,
    uid: numberOrBlank
  },

  'GET /star/star/:starId/recommendVideo': {
    starId: number,
    tag: isRequired,
    category: '1|2'
  }
};

function isRequired (value) {
  return value !== 'undefined' && value !== 'null' && !!value;
}