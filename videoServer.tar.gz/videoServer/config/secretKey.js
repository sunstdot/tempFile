/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: 不同接口方用于生成签名的 secretKey,如果是平台方首次使用，需向接口方申请
 * @author: zhoujie@qiyi.com
 * @date:   2017-12-06
 */
const secretKey = {
    userBasicInfoKey: "pijnec03985w$aoip",       //passport接口用户获取用户基本信息key
    userBusinessTypesKey: "82f4242aa79619bef8efcfc632f364e3"       //renzheng接口用户获取用户业务列表key
}
module.exports = secretKey;