/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: default config module for frameWork
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 * 
 */