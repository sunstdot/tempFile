/**
 * Copyright 2018 Qiyi Inc. All rights reserved.
 *
 * @desc: 过滤掉路由某些变化类字段，从varnish中读取缓存
 * @author: sunshitao@qiyi.com
 * @date:   2018-07-03
 */
module.exports = {
  common: ['callback', 'cb', 't'] //通用过滤字段
};