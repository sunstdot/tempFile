/**
 * Copyright 2017 Qiyi Inc. All rights reserved.
 *
 * @desc: production config module for frameWork
 * @author: sunshitao@qiyi.com
 * @date:   2017-04-10
 */
module.exports = {
    security: {
        whiteList: ['127.0.0.1','10','192']
    }
};
