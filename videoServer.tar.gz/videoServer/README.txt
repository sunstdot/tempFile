##PCW-API 目录规范
ZeusServer目录根据pcw业务与功能进行划分
1.controller文件夹下分为专辑，视频，openApi，mixer等业务文件夹，文件夹内业务文件暂定以业务名命名比如album.js video.js
主要是处理对应业务的接口请求，mixer文件夹下存放的是夸业务团队的整合类接口请求
2.service文件夹下的文件与controller下目录一一对应，存放于对应业务或功能相关的数据接口及内部整合后的数据接口，album,video,openapi 
提供对应业务的原始数据请求，如找不到对应业务方的接口 归类到thirdParty目录下，比如Ai团队提供的接口，它不属于任何一个常用业务方，mixer内
处理的整合类请求服务可直接调用对应业务接口的service服务，比如大首页继续看功能接口continueWatch 由mixer+recommend+passport三方接口
merge成，continueWatch.js需要放在mixer文件夹下， 然后调用对应的mixer,recommend,passport的service 在continueWatch.js中做
后续数据处理，然后返回给调用方
3.model，dao，跟controller类似，分文件大类进行对应数据跟接口的处理，不做文件夹细分，只分层到具体文件这一级

##ZeusServer 代码规范
1.ZeusServer中业务代码的编写需在严格模式下进行 即 ‘use strict’，文件最顶部需要加规范化的注释
2.文件名，函数名以小驼峰形式命名，类名以大驼峰形式命名
3.编写代码模块时 {} 大括号前需有空格  比如`if() {}` 函数也一样 `function() {}`
4.换行缩进为四个空格
5.代码书写格式都遵循类继承 类内实现具体功能函数的形式进行代码编写，详见 controller/album/album.js内的编写
6.代码中尽量使用单引号 包括但不限于 require('xxx'), 一般字符串处理 等等

